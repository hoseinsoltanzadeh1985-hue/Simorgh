import asyncio, json, os, sys, signal
from pyrogram import Client
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream

API_ID = int(os.environ.get("TG_API_ID", "0"))
API_HASH = os.environ.get("TG_API_HASH", "")
SESSION = os.environ.get("TG_USER_SESSION", "voice_worker")

if not API_ID or not API_HASH:
    raise SystemExit("TG_API_ID and TG_API_HASH are required for the real Voice Chat engine")

client = Client(SESSION, api_id=API_ID, api_hash=API_HASH, session_string=os.environ.get("TG_SESSION_STRING") or None)
call = PyTgCalls(client)

async def main():
    await client.start()
    await call.start()
    loop = asyncio.get_running_loop()
    for line in sys.stdin:
        line=line.strip()
        if not line: continue
        req=json.loads(line)
        op=req.get("op"); chat=int(req.get("chat_id",0))
        try:
            if op == "play":
                source=req["source"]
                await call.play(chat, MediaStream(source, video_flags=MediaStream.Flags.IGNORE))
                out={"ok":True,"op":op,"chat_id":chat}
            elif op == "pause":
                await call.pause(chat); out={"ok":True}
            elif op == "resume":
                await call.resume(chat); out={"ok":True}
            elif op == "stop":
                await call.leave_call(chat); out={"ok":True}
            elif op == "join":
                # A no-op play is not used: current PyTgCalls joins when play is invoked.
                out={"ok":True,"note":"join is performed by play() in this engine"}
            else:
                out={"ok":False,"error":"unknown operation"}
        except Exception as e:
            out={"ok":False,"error":str(e),"op":op,"chat_id":chat}
        print(json.dumps(out,ensure_ascii=False), flush=True)
    await call.stop()
    await client.stop()

if __name__ == "__main__":
    asyncio.run(main())
