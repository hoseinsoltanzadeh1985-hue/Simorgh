# PediGuardian 4.4 Unified

Single source of truth: Java 21 core + one Cloud Edge Function (`telegram-webhook-v4`).
The Cloud deployment revision number is Supabase-controlled and is not the product version.
Product version is APP_VERSION=4.4.0.
