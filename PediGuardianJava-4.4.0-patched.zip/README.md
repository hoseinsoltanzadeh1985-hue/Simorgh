# PediGuardian 4.4.0 Unified Cloud Final

Production-focused Telegram group guardian for Java 21 + Supabase.

## What is improved
- Cloud-safe deployment mode: Java does not delete an externally-managed Telegram webhook.
- Defense-in-depth RBAC with role floors, Telegram admin rights, and target hierarchy protection.
- Idempotent update handling in cloud (`telegram_updates`).
- Bounded rate/flood control and cleanup.
- Expanded lock detection for links, media, forwards, entities, captions, Zalgo, etc.
- Role-aware bilingual inline panels and a smaller public command surface.
- Audit trail and structured Cloud state tables.
- Groq-first AI with provider failover on the Java side.
- Game Center API with verified Telegram Mini App initData and leaderboard.
- Game frontend is static-host friendly; Edge Function is API-only.
- Music/Voice remains a separate persistent worker (not inside Edge Functions).

## Security posture
The bot is designed around the OWASP API Security Top 10: object/function authorization, authentication, resource limits, security configuration, API inventory, and safe third-party API consumption are explicit concerns.

No software can honestly be called "unhackable". The goal is defense in depth, minimal secrets exposure, least privilege, bounded resources, safe failure, and auditable actions.


## Release 4.4.0 Final
- Cloud webhook v4 compatible; `/start@bot` and `/panel@bot` normalize to the command name.
- Cloud mode never deletes an externally managed webhook.
- Group moderation checks Telegram administrator rights and target hierarchy.
- Idempotent Telegram updates use `telegram_updates`.
- Bounded local rate/flood controls.
- Public responses do not echo the bot username.
- Java 21 single JAR; no third-party runtime dependencies.

### Termux
Set `DEPLOYMENT_MODE=cloud` only for a local controller/diagnostic process. The cloud webhook remains the active receiver. Do not run polling concurrently with the cloud webhook.


### 4.2 additions
- Competitor Session Station strengths integrated where useful.
- Server-side Supabase audit/idempotency sink for local/hybrid operation.
- Current Telegram member-tag support with native `can_manage_tags` check.
- Security advisor remediation: public execution of security-definer helper functions revoked; server-only deny policies added for cloud-only tables.
- Duplicate manual indexes removed while retaining constraint-backed uniqueness; AI group foreign-key index added.
- Cloud webhook remains the primary runtime; no JAR polling is required for 24/7 webhook delivery.


### Cloud deployment state
- Supabase `telegram-webhook-v4` is the active webhook function; current deployment revision is maintained independently from the product version.
- Telegram Webhook remains on the same function URL, so no URL change is required after deployment.
- Supabase security advisors were clean at final verification.
- Performance advisor may still report informational unused indexes; redundant duplicate indexes were removed where they were clearly manual duplicates of constraint-backed indexes.
