# PediGuardian 4.4.0 patched

Changes:
- Main panel callbacks no longer fall through to a Cloud-only placeholder.
- Section action buttons now execute or give the correct local action/help.
- HTML is enabled for edited panel messages, preventing raw `<b>` tags from showing.
- Air Raider is automatically wired to the HTTPS Supabase Web App endpoint:
  https://ygzabgsyfehmlaarphpx.supabase.co/functions/v1/pedi-air-raider
- Existing environment variable `GAME_URL` still overrides the default.

Built with Java 21-compatible javac. No dependency download is required for the patched JAR.
