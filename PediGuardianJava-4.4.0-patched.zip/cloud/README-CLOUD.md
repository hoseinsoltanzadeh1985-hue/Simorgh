# PediGuardian 4 Cloud
Primary runtime: Telegram Webhook -> Supabase Edge Function -> PostgreSQL.

Cloud handler includes: secret validation, update idempotency, /command@bot normalization, role-aware panels, native Telegram permission checks, Rich Message fallback, ephemeral group responses, private AI drafts/streaming, dynamic badwords, locks, moderation, reports, rules, welcome, Game Mini App button, and audit logging.

The Java runtime is emergency/local only in CLOUD mode and must not delete the Telegram webhook.
Music/Voice remains a separate persistent worker; the management core does not advertise a non-working voice engine.
