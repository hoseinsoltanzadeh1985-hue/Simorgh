const APP_VERSION = "4.4.0";
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const BOT = Deno.env.get("TELEGRAM_BOT_TOKEN") || "";
const SECRET = Deno.env.get("TELEGRAM_WEBHOOK_SECRET") || "";
const OWNER = Number(Deno.env.get("BOT_OWNER_ID") || "0");
const GROQ = Deno.env.get("GROQ_API_KEY") || "";
const MODEL = Deno.env.get("GROQ_MODEL") || "openai/gpt-oss-120b";
const GAME_URL = Deno.env.get("GAME_URL") || "";
const TG = `https://api.telegram.org/bot${BOT}`;
const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

const rank: Record<string, number> = { RESTRICTED:0, MEMBER:1, HELPER:2, MODERATOR:3, ADMIN:4, SENIOR_ADMIN:5, GROUP_OWNER:6, BOT_OWNER:7 };
const minRole: Record<string, number> = { AI:1, GAME:1, EMOJI:1, WARN:3, MUTE:3, DELETE:3, BAN:4, PIN:4, LOCKS:4, REPORTS:4, WELCOME:4, FILTERS:4, ANTIRAID:4, ADMINS:5, SETTINGS:5, NOTES:5, HELPER:2 };
const canRole = (r: string, p: string) => (rank[r] ?? 1) >= (minRole[p] ?? 99);
const text = (v: unknown) => typeof v === "string" ? v : "";
const esc = (s: string) => s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");
const json = (x: unknown, s=200) => new Response(JSON.stringify(x), {status:s, headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});

async function tg(method: string, body: Record<string, unknown>) {
  if (!BOT) throw new Error("TELEGRAM_BOT_TOKEN missing");
  const r = await fetch(`${TG}/${method}`, { method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify(body) });
  const j = await r.json();
  if (!r.ok || !j.ok) throw new Error(`${method}: ${j.description || r.status}`);
  return j.result;
}

function kb(rows: string[][][]) {
  return JSON.stringify({inline_keyboard: rows.map(row => row.map(([t,d]) => ({text:t, callback_data:d}))))});
}

function menu(role: string) {
  const rows: string[][][] = [
    [["👥 اعضا | Members","p:members"],["🤖 هوش | AI","p:ai"]],
    [["🎮 بازی | Games","p:games"],["😀 ایموجی | Emoji","p:emoji"]]
  ];
  if ((rank[role]??1) >= 3) rows.push([["🔨 مدیریت | Moderation","p:mod"],["🔒 قفل‌ها | Locks","p:locks"]]);
  if ((rank[role]??1) >= 4) rows.push([["🛡 امنیت | Security","p:security"],["📊 گزارش | Reports","p:reports"]]);
  if ((rank[role]??1) >= 5) rows.push([["👮 نقش‌ها | Roles","p:roles"],["⚙️ تنظیمات | Settings","p:settings"]]);
  rows.push([["🎨 تم | Theme","p:theme"],["👤 پروفایل | Profile","p:profile"]]);
  return kb(rows);
}

function page(role: string, p: string) {
  const r = rank[role] ?? 1;
  if (["members","mod"].includes(p) && r < 3) return null;
  if (["locks","security","reports"].includes(p) && r < 4) return null;
  if (["roles","settings"].includes(p) && r < 5) return null;
  switch (p) {
    case "members": return kb([[ ["👮 مدیران | Admins","a:admins"],["⚠️ اخطارها | Warnings","a:warnings"] ],[["📊 گزارش | Reports","p:reports"],["◀️ بازگشت | Back","p:main"]]]);
    case "mod": return kb([[ ["⚠️ Warn","a:warn"],["🔇 Mute","a:mute"] ],[["🚫 Ban","a:ban"],["🗑 Delete","a:delete"]],[["📌 Pin","a:pin"],["🧹 Purge","a:purge"]],[["◀️ Back","p:main"]]]);
    case "security": return kb([[ ["🚨 Anti-spam","a:antispam"],["🧱 Anti-raid","a:antiraid"] ],[["🔗 Anti-link","a:antilink"],["🔐 Status","a:security"]],[["◀️ Back","p:main"]]]);
    case "locks": return kb([[ ["🔗 Links","l:links"],["↪️ Forward","l:forwards"] ],[["🖼 Photos","l:photos"],["🎥 Videos","l:videos"]],[["📄 Files","l:documents"],["🎤 Voice","l:voice"]],[["🧩 Stickers","l:stickers"],["😀 GIF","l:gifs"]],[["🚨 Bad Words","l:badwords"],["◀️ Back","p:main"]]]);
    case "ai": return kb([[ ["🤖 تست AI | Test","a:ai"],["📊 وضعیت | Status","a:aistatus"] ],[["◀️ Back","p:main"]]]);
    case "games": return GAME_URL ? kb([[ ["✈️ Air Raider","game:open"],["🏆 Scores","game:scores"] ],[["◀️ Back","p:main"]]]) : kb([[ ["ℹ️ وضعیت بازی","a:gameinfo"] ],[["◀️ Back","p:main"]]]);
    case "emoji": return kb([[ ["📷 ساخت از عکس | Create","a:emoji"] ],[["✨ راهنما | Guide","a:emojihelp"]],[["◀️ Back","p:main"]]]);
    case "reports": return kb([[ ["📊 گزارش‌های باز | Open","a:reports"],["📜 Audit","a:logs"] ],[["◀️ Back","p:main"]]]);
    case "roles": return kb([[ ["👮 Admins","a:admins"],["🔐 Permissions","a:perms"] ],[["⭐ Senior Admin","a:senior"]],[["◀️ Back","p:main"]]]);
    case "settings": return kb([[ ["📜 Rules","a:rules"],["👋 Welcome","a:welcome"] ],[["📝 Filters","a:filters"],["📌 Notes","a:notes"]],[["🌐 Language","a:language"],["🎨 Theme","p:theme"]],[["◀️ Back","p:main"]]]);
    case "theme": return kb([[ ["🌙 Midnight","theme:midnight"],["🌊 Ocean","theme:ocean"] ],[["🌿 Emerald","theme:emerald"],["☀️ Light","theme:light"]],[["◀️ Back","p:main"]]]);
    case "profile": return kb([[ ["🌐 فارسی / English","a:language"] ],[["◀️ Back","p:main"]]]);
    default: return kb([[ ["◀️ Back","p:main"] ]]);
  }
}

async function groupId(chatId: number, title: string|null) {
  const {data,error} = await db.from("groups").upsert({telegram_chat_id:chatId,title},{onConflict:"telegram_chat_id"}).select("id").single();
  if (error) throw error; return Number(data.id);
}
async function saveMember(gid:number,u:any,role?:string) {
  if (!u?.id) return;
  const patch:any = {group_id:gid,telegram_user_id:Number(u.id),username:u.username||null,display_name:[u.first_name,u.last_name].filter(Boolean).join(" ")||null};
  if (role) patch.role = role;
  const {error}=await db.from("members").upsert(patch,{onConflict:"group_id,telegram_user_id"});
  if(error) throw error;
}
async function roleOf(chatId:number,userId:number,gid:number,chatType:string) {
  if (OWNER && userId===OWNER) return "BOT_OWNER";
  if (chatType === "private") return "MEMBER";
  const cm = await tg("getChatMember",{chat_id:chatId,user_id:userId});
  if (cm?.status === "creator") return "GROUP_OWNER";
  const {data}=await db.from("members").select("role,status").eq("group_id",gid).eq("telegram_user_id",userId).maybeSingle();
  if (cm?.status === "administrator") return data?.role === "SENIOR_ADMIN" ? "SENIOR_ADMIN" : "ADMIN";
  if (["left","kicked"].includes(cm?.status) || data?.status === "banned" || data?.role === "RESTRICTED") return "RESTRICTED";
  return ["HELPER","MODERATOR"].includes(data?.role) ? data.role : "MEMBER";
}
async function audit(gid:number,actor:number,action:string,target:number|null=null,metadata:any={}) { await db.from("audit_logs").insert({group_id:gid,actor_user_id:actor,action,target_user_id:target,metadata}); }
async function protectedTarget(chatId:number,target:number) {
  if (OWNER && target===OWNER) return true;
  const m=await tg("getChatMember",{chat_id:chatId,user_id:target});
  return m?.status === "creator" || m?.status === "administrator";
}
async function canAct(chatId:number,actor:number,target:number,perm:string,actorRole:string) {
  if (!canRole(actorRole,perm) || await protectedTarget(chatId,target)) return false;
  const ar=rank[actorRole]??1;
  const tr=rank[await roleOf(chatId,target,await groupId(chatId,null), "supergroup")]??1;
  if (actorRole !== "BOT_OWNER" && tr >= ar) return false;
  const me=await tg("getChatMember",{chat_id:chatId,user_id:actor});
  if (me?.status === "creator") return true;
  if (me?.status !== "administrator") return false;
  if (["WARN","MUTE","BAN"].includes(perm)) return !!me.can_restrict_members;
  if (perm === "DELETE") return !!me.can_delete_messages;
  if (perm === "PIN") return !!me.can_pin_messages;
  if (perm === "ADMINS") return !!me.can_promote_members;
  if (["SETTINGS","WELCOME"].includes(perm)) return !!me.can_change_info;
  return true;
}
async function ai(prompt:string){
  if(!GROQ) return null;
  const r=await fetch("https://api.groq.com/openai/v1/chat/completions",{method:"POST",headers:{"content-type":"application/json",authorization:`Bearer ${GROQ}`},body:JSON.stringify({model:MODEL,messages:[{role:"system",content:"You are PediGuardian AI. Default Persian. Concise, accurate. Never perform moderation actions from prose."},{role:"user",content:prompt.slice(0,6000)}],temperature:0.2})});
  if(!r.ok) return null; const j=await r.json(); return j?.choices?.[0]?.message?.content||null;
}
function commandName(raw:string){ const token=raw.trim().split(/\s+/,1)[0].toLowerCase(); const at=token.indexOf("@"); return at>0?token.slice(0,at):token; }

Deno.serve(async req=>{
  if(req.method!=="POST") return new Response("OK");
  if(!SECRET) return json({ok:false,error:"webhook_not_configured"},500);
  if(req.headers.get("x-telegram-bot-api-secret-token")!==SECRET) return new Response("Unauthorized",{status:401});
  const len=Number(req.headers.get("content-length")||0); if(len>524288) return json({ok:false,error:"payload_too_large"},413);
  try{
    const u=await req.json(); const uid=Number(u?.update_id||0);
    if(uid){const {error}=await db.from("telegram_updates").insert({update_id:uid}); if(error?.code==="23505") return json({ok:true}); if(error) throw error;}
    if(u?.callback_query){
      const cb=u.callback_query, msg=cb.message||{}, chat=msg.chat||{}, chatId=Number(chat.id||0), userId=Number(cb.from?.id||0); if(!chatId)return json({ok:true});
      const isPrivate=String(chat.type||"")==="private"; const gid=isPrivate?0:await groupId(chatId,chat.title||null); const role=await roleOf(chatId,userId,gid,String(chat.type||"group")); if(!isPrivate) await saveMember(gid,cb.from,role); const d=text(cb.data);
      if(d==="p:main"){await tg("answerCallbackQuery",{callback_query_id:cb.id,text:"✅"});await tg("editMessageText",{chat_id:chatId,message_id:msg.message_id,text:`🛡️ <b>PediGuardian Cloud</b>\n👤 ${role}\n☁️ Online`,parse_mode:"HTML",reply_markup:menu(role)});return json({ok:true});}
      if(d.startsWith("p:")){const p=d.slice(2),mk=page(role,p);if(!mk){await tg("answerCallbackQuery",{callback_query_id:cb.id,text:"⛔ دسترسی ندارید",show_alert:true});return json({ok:true});}await tg("answerCallbackQuery",{callback_query_id:cb.id,text:"✅"});await tg("editMessageText",{chat_id:chatId,message_id:msg.message_id,text:`🪟 <b>${esc(p)}</b>`,parse_mode:"HTML",reply_markup:mk});return json({ok:true});}
      if(d.startsWith("l:")){if(!canRole(role,"LOCKS")){await tg("answerCallbackQuery",{callback_query_id:cb.id,text:"⛔",show_alert:true});return json({ok:true});}const lt=d.slice(2),{data:old}=await db.from("locks").select("enabled").eq("group_id",gid).eq("lock_type",lt).maybeSingle(),enabled=!old?.enabled;await db.from("locks").upsert({group_id:gid,lock_type:lt,enabled,action:"delete"},{onConflict:"group_id,lock_type"});await audit(gid,userId,enabled?"LOCK_ON":"LOCK_OFF",null,{lock_type:lt});await tg("answerCallbackQuery",{callback_query_id:cb.id,text:enabled?"🔒 ON":"🔓 OFF"});return json({ok:true});}
      if(d.startsWith("theme:")){const theme=d.slice(6);if(["midnight","ocean","emerald","light"].includes(theme)){await db.from("user_preferences").upsert({telegram_user_id:userId,theme},{onConflict:"telegram_user_id"});await tg("answerCallbackQuery",{callback_query_id:cb.id,text:`🎨 ${theme}`});}return json({ok:true});}
      if(d==="game:open" && GAME_URL){await tg("answerCallbackQuery",{callback_query_id:cb.id});await tg("sendMessage",{chat_id:chatId,text:"🎮 <b>Pedi Air Raider</b>\nبازی را باز کنید و رکوردتان را ثبت کنید.",parse_mode:"HTML",reply_markup:JSON.stringify({inline_keyboard:[[ {text:"✈️ Play",web_app:{url:GAME_URL}} ]]})});return json({ok:true});}
      if(d==="a:ai"){await tg("answerCallbackQuery",{callback_query_id:cb.id,text:"💬 از /ai سؤال بپرسید."});return json({ok:true});}
      if(d==="a:aistatus"){await tg("answerCallbackQuery",{callback_query_id:cb.id,text:GROQ?`🤖 ${MODEL}`:"🤖 AI خاموش",show_alert:true});return json({ok:true});}
      if(d==="a:gameinfo"){await tg("answerCallbackQuery",{callback_query_id:cb.id,text:GAME_URL?"🎮 بازی آماده است":"🎮 URL بازی تنظیم نشده",show_alert:true});return json({ok:true});}
      if(d==="a:emojihelp"){await tg("answerCallbackQuery",{callback_query_id:cb.id,text:"📷 عکس را Reply کنید؛ Emoji Studio نسخه کامل Cloud در حال تکمیل است.",show_alert:true});return json({ok:true});}
      await tg("answerCallbackQuery",{callback_query_id:cb.id,text:"ℹ️ این بخش در پنل Cloud مدیریت می‌شود.",show_alert:true});return json({ok:true});
    }
    const m=u?.message; if(!m?.chat?.id)return json({ok:true});
    const chat=m.chat, chatId=Number(chat.id), userId=Number(m.from?.id||0), isPrivate=String(chat.type||"")==="private", gid=isPrivate?0:await groupId(chatId,chat.title||null), role=await roleOf(chatId,userId,gid,String(chat.type||"group"));
    if(!isPrivate) await saveMember(gid,m.from,role);
    const raw=text(m.text).trim(), cmd=commandName(raw), target=Number(m.reply_to_message?.from?.id||0)||null, targetMsg=Number(m.reply_to_message?.message_id||0)||null;
    if(raw.startsWith("/")){
      switch(cmd){
        case "/start": case "/panel": return await tg("sendMessage",{chat_id:chatId,text:`🛡️ <b>PediGuardian 4.4 Cloud</b>\n☁️ Cloud: Online\n🔐 Security: Active\n👤 Role: ${role}`,parse_mode:"HTML",reply_markup:menu(role)}).then(()=>json({ok:true}));
        case "/version": return await tg("sendMessage",{chat_id:chatId,text:`🛡️ <b>PediGuardian ${APP_VERSION}</b>\n☁️ Unified Cloud\n🤖 AI • 🔐 Security • 🎮 Game • 🧩 Modules`,parse_mode:"HTML"}).then(()=>json({ok:true}));
        case "/help": return await tg("sendMessage",{chat_id:chatId,text:"📚 <b>راهنما | Help</b>\n\nاز پنل برای مشاهده امکانات مجاز استفاده کنید.\n\n/panel • /ai • /game • /emoji • /status • /rules",parse_mode:"HTML"}).then(()=>json({ok:true}));
        case "/status": return await tg("sendMessage",{chat_id:chatId,text:`🟢 <b>Cloud Online</b>\n👤 ${role}\n🤖 AI: ${GROQ?"On":"Off"}\n🎮 Game: ${GAME_URL?"Ready":"Not configured"}`,parse_mode:"HTML"}).then(()=>json({ok:true}));
        case "/profile": return await tg("sendMessage",{chat_id:chatId,text:`👤 ID: <code>${userId}</code>\nRole: <b>${role}</b>`,parse_mode:"HTML"}).then(()=>json({ok:true}));
        case "/language": return await tg("sendMessage",{chat_id:chatId,text:"🌐 فارسی / English"}).then(()=>json({ok:true}));
        case "/rules": {const {data}=await db.from("groups").select("settings").eq("id",gid).maybeSingle();return await tg("sendMessage",{chat_id:chatId,text:String(data?.settings?.rules||"📜 قانونی ثبت نشده.")}).then(()=>json({ok:true}));}
        case "/game": return GAME_URL?await tg("sendMessage",{chat_id:chatId,text:"🎮 <b>Pedi Air Raider</b>",parse_mode:"HTML",reply_markup:JSON.stringify({inline_keyboard:[[ {text:"✈️ شروع بازی | Play",web_app:{url:GAME_URL}} ]]})}).then(()=>json({ok:true})):await tg("sendMessage",{chat_id:chatId,text:"🎮 بازی هنوز URL قابل اجرا ندارد."}).then(()=>json({ok:true}));
        case "/ai": {const prompt=raw.replace(/^\/ai(?:@[^\s]+)?\s*/i,""); if(!prompt)return await tg("sendMessage",{chat_id:chatId,text:"استفاده: /ai سؤال"}).then(()=>json({ok:true}));const st=Date.now(),answer=await ai(prompt);await db.from("ai_usage").insert({telegram_user_id:userId,group_id:gid,provider:GROQ?"groq":"none",model:MODEL,latency_ms:Date.now()-st,success:!!answer});return await tg("sendMessage",{chat_id:chatId,text:answer||"⚠️ AI موقتاً در دسترس نیست."}).then(()=>json({ok:true}));}
      }
      if(["/warn","/mute","/ban","/kick","/del","/pin","/unpin"].includes(cmd)){
        const perm=cmd==="/del"?"DELETE":(["/pin","/unpin"].includes(cmd)?"PIN":(["/ban","/kick"].includes(cmd)?"BAN":cmd.slice(1).toUpperCase()));
        if(!target && perm!=="DELETE" && !targetMsg)return json({ok:true});
        const t=target||targetMsg||0;
        if(!canRole(role,perm)||!await canAct(chatId,userId,t,perm,role))return json({ok:true});
        if(cmd==="/warn")await db.from("warnings").insert({group_id:gid,telegram_user_id:t,reason:"manual",issued_by:userId});
        else if(cmd==="/mute")await tg("restrictChatMember",{chat_id:chatId,user_id:t,permissions:JSON.stringify({can_send_messages:false}),use_independent_chat_permissions:true});
        else if(cmd==="/ban")await tg("banChatMember",{chat_id:chatId,user_id:t,revoke_messages:true});
        else if(cmd==="/kick"){await tg("banChatMember",{chat_id:chatId,user_id:t,revoke_messages:false});await tg("unbanChatMember",{chat_id:chatId,user_id:t,only_if_banned:true});}
        else if(cmd==="/del")await tg("deleteMessage",{chat_id:chatId,message_id:t});
        else if(cmd==="/pin")await tg("pinChatMessage",{chat_id:chatId,message_id:t,disable_notification:true});
        else await tg("unpinChatMessage",{chat_id:chatId,message_id:t});
        await audit(gid,userId,cmd.slice(1).toUpperCase(),t);
        return json({ok:true});
      }
      if(cmd==="/lock"||cmd==="/unlock"){if(!canRole(role,"LOCKS"))return json({ok:true});const type=text(raw.split(/\s+/,2)[1]||"").toLowerCase();if(!type)return json({ok:true});await db.from("locks").upsert({group_id:gid,lock_type:type,enabled:cmd==="/lock",action:"delete"},{onConflict:"group_id,lock_type"});await audit(gid,userId,cmd.slice(1).toUpperCase(),null,{lock_type:type});return json({ok:true});}
      return json({ok:true});
    }
    return json({ok:true});
  }catch(e){console.error(e);return json({ok:false,error:"internal"},500)}
});
