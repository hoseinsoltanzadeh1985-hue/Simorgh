# PediGuardian 4.4 Unified Cloud deployment status

Product version: 4.4.0
Supabase project ref: ygzabgsyfehmlaarphpx
Active receiver: telegram-webhook-v4

The Supabase Edge Function revision number is provider-managed and is not the product version.
Single source of truth: `cloud/supabase/functions/telegram-webhook-v4/index.ts`

Do not run Java polling concurrently with the Cloud webhook.
