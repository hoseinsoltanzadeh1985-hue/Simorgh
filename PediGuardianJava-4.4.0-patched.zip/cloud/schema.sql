-- PediGuardian 4 Cloud schema hardening
alter table public.members drop constraint if exists members_role_check;
alter table public.members add constraint members_role_check
check (role = any (array['BOT_OWNER','GROUP_OWNER','SENIOR_ADMIN','ADMIN','MODERATOR','HELPER','MEMBER','RESTRICTED']));
alter table public.members alter column role set default 'MEMBER';
create index if not exists idx_members_group_role on public.members(group_id, role);
create index if not exists idx_game_scores_game_score on public.game_scores(game, score desc);
create index if not exists idx_audit_logs_group_created on public.audit_logs(group_id, created_at desc);
