import ir.pedirany.guardian.telegram.Json;
import ir.pedirany.guardian.storage.StateStore;
import ir.pedirany.guardian.commands.CommandRegistry;
import java.nio.file.*;

public class FunctionalSmoke {
  public static void main(String[] args) throws Exception {
    Object n = Json.obj(Json.parse("{\"update_id\":9223372036854770000,\"ok\":true}" )).get("update_id");
    if (!(n instanceof Long)) throw new AssertionError("JSON integer lost precision/type");
    CommandRegistry r = new CommandRegistry();
    r.register("start", c -> {});
    if (r.resolve("/start@Simorgh2026bot") == null) throw new AssertionError("command alias failed");
    Path f = Files.createTempDirectory("pedi-smoke-").resolve("state.properties");
    StateStore s = new StateStore(f.toString());
    s.load(); s.setBadword(1L,"SPAM",true);
    if (!s.badwords(1L).contains("spam")) throw new AssertionError("badword failed");
    s.setWarningLimit(1L, 3); s.addWarning(1L, 2L);
    s.flush();
    StateStore s2 = new StateStore(f.toString()); s2.load();
    if (s2.warnings(1L,2L) != 1) throw new AssertionError("state reload failed");
    System.out.println("FUNCTIONAL_SMOKE_OK");
  }
}
