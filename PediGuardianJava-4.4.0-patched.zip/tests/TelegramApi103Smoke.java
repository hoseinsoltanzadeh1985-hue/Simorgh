public class TelegramApi103Smoke {
  public static void main(String[] args) throws Exception {
    String src = java.nio.file.Files.readString(java.nio.file.Path.of("src/main/java/ir/pedirany/guardian/telegram/TelegramClient.java"));
    if (!src.contains("ephemeral_message_parameters")) throw new AssertionError("10.3 ephemeral schema missing");
    if (!src.contains("sendRichMessageDraft")) throw new AssertionError("Rich draft missing");
    System.out.println("TELEGRAM_API_103_SMOKE_OK");
  }
}
