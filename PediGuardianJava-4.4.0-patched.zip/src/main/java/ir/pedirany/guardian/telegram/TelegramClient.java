package ir.pedirany.guardian.telegram;

import java.io.IOException;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;

/** Dependency-free Telegram Bot API client with strict redirects and typed helpers. */
public final class TelegramClient {
    private final String base;
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .followRedirects(HttpClient.Redirect.NEVER).build();
    private volatile Long botIdCache;

    public TelegramClient(String token) {
        if (token == null || token.isBlank()) throw new IllegalArgumentException("BOT_TOKEN is empty");
        this.base = "https://api.telegram.org/bot" + token;
    }

    public Map<String,Object> call(String method, Map<String,Object> params) throws Exception {
        String body = encode(params);
        HttpRequest req = HttpRequest.newBuilder(URI.create(base + "/" + method))
                .timeout(Duration.ofSeconds(60))
                .header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8)).build();
        HttpResponse<String> r;
        try { r = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw e; }
        catch (IOException e) { throw new IOException("Telegram network/timeout error", e); }
        Map<String,Object> root;
        try { root = Json.obj(Json.parse(r.body())); }
        catch (RuntimeException e) { throw new IOException("Telegram returned invalid JSON", e); }
        if (!Boolean.TRUE.equals(root.get("ok"))) {
            throw new TelegramException(String.valueOf(root.getOrDefault("description", "Telegram API error")), r.statusCode(), number(root.get("retry_after"), 0));
        }
        Object result = root.get("result");
        return result instanceof Map ? Json.obj(result) : Map.of("value", result);
    }

    public List<Object> getUpdates(long offset, int timeout) throws Exception {
        Map<String,Object> r = call("getUpdates", Map.of(
                "offset", offset, "timeout", Math.max(1, Math.min(timeout, 50)),
                "allowed_updates", "[\"message\",\"edited_message\",\"callback_query\",\"my_chat_member\",\"chat_member\",\"chat_join_request\"]"));
        Object v = r.get("value");
        return v instanceof List<?> l ? new ArrayList<>(l) : List.of();
    }

    public void deleteWebhook() throws Exception { call("deleteWebhook", Map.of("drop_pending_updates", false)); }
    public void setWebhook(String url, String secret) throws Exception {
        if (url == null || !url.startsWith("https://")) throw new IllegalArgumentException("Webhook URL must be HTTPS");
        if (secret == null || secret.length() < 16 || secret.length() > 256) throw new IllegalArgumentException("Webhook secret must be 16-256 chars");
        call("setWebhook", Map.of("url", url, "secret_token", secret, "drop_pending_updates", false,
                "allowed_updates", "[\"message\",\"edited_message\",\"callback_query\",\"my_chat_member\",\"chat_member\",\"chat_join_request\"]"));
    }

    /** Telegram Bot API requires every scope object to include its type field. */
    public void setCommands() throws Exception {
        setMyCommands(commands(false), "default");
        setMyCommands(commands(true), "all_chat_administrators");
        setMyCommands(commands(false), "all_private_chats");
    }

    private void setMyCommands(List<Map<String,String>> commands, String scopeType) throws Exception {
        String scope = "{\"type\":" + q(scopeType) + "}";
        call("setMyCommands", Map.of("commands", arrayJson(commands), "scope", scope));
    }

    private static List<Map<String,String>> commands(boolean admin) {
        List<Map<String,String>> out = new ArrayList<>(cmds(new String[][]{
                {"start","Start / شروع"},{"help","Help / راهنما"},{"panel","Panel / پنل"},{"status","Status / وضعیت"},
                {"id","ID / شناسه"},{"profile","Profile / پروفایل"},{"rules","Rules / قوانین"},{"ai","AI / هوش مصنوعی"},
                {"game","Games / بازی‌ها"},{"emoji","Emoji / ایموجی"},{"language","Language / زبان"},{"version","Version / نسخه"},
                {"report","Report / گزارش"}
        }));
        if (admin) out.addAll(cmds(new String[][]{
                {"warn","Warn / اخطار"},{"warnings","Warnings / اخطارها"},{"clearwarnings","Clear warnings / پاک اخطارها"},                {"setwarninglimit","Warning limit / حد اخطار"},{"settag","Member tag / برچسب عضو"},
                {"mute","Mute / سکوت"},{"unmute","Unmute / رفع سکوت"},{"ban","Ban / مسدود"},{"unban","Unban / رفع مسدودی"},
                {"kick","Kick / اخراج"},{"del","Delete / حذف"},{"pin","Pin / سنجاق"},{"unpin","Unpin / برداشتن سنجاق"},
                {"lock","Lock / قفل"},{"unlock","Unlock / بازکردن قفل"},{"locks","Locks / قفل‌ها"},{"security","Security / امنیت"},
                {"admins","Admins / مدیران"},{"addadmin","Add admin / افزودن مدیر"},{"removeadmin","Remove admin / حذف مدیر"},
                {"grantperm","Grant / اعطای دسترسی"},{"revokeperm","Revoke / لغو دسترسی"},{"perms","Permissions / دسترسی‌ها"},
                {"logs","Audit / لاگ"},{"reports","Reports / گزارش‌ها"},{"settings","Settings / تنظیمات"},
                {"setrules","Set rules / تنظیم قوانین"},{"welcome","Welcome / خوشامد"},{"setwelcome","Set welcome / تنظیم خوشامد"},
                {"filter","Filter / فیلتر"},{"filters","Filters / فیلترها"},{"note","Note / یادداشت"},{"notes","Notes / یادداشت‌ها"},
                {"antiraid","Anti-Raid / ضدحمله"},{"purge","Purge / پاکسازی"}
        }));
        return out;
    }

    private static List<Map<String,String>> cmds(String[][] a) {
        List<Map<String,String>> l = new ArrayList<>();
        for (String[] x : a) l.add(Map.of("command", x[0], "description", x[1]));
        return l;
    }

    public Map<String,Object> getChatMember(long chat,long user)throws Exception{return call("getChatMember",Map.of("chat_id",chat,"user_id",user));}
    public List<Object> getChatAdministrators(long chat)throws Exception{Object v=call("getChatAdministrators",Map.of("chat_id",chat)).get("value");return v instanceof List<?> l?new ArrayList<>(l):List.of();}
    public Map<String,Object> getMe()throws Exception{return call("getMe",Map.of());}
    public long botId() throws Exception { Long id=botIdCache; if(id!=null)return id; id=number(getMe().get("id"),0); botIdCache=id; return id; }

    public void sendMessage(long chat,String text)throws Exception{sendMessage(chat,text,null,false);}
    public void sendMessage(long chat,String text,String markup)throws Exception{sendMessage(chat,text,markup,false);}
    public void sendMessage(long chat,String text,String markup,boolean html)throws Exception{sendMessage(chat,text,markup,html,null,null);}
    public void sendMessage(long chat,String text,String markup,boolean html,Long receiverUserId,String callbackQueryId)throws Exception{
        Map<String,Object> p=new LinkedHashMap<>();p.put("chat_id",chat);p.put("text",text);if(html)p.put("parse_mode","HTML");if(markup!=null&&!markup.isBlank())p.put("reply_markup",markup);
        if(receiverUserId!=null){ Map<String,Object> ep=new LinkedHashMap<>();ep.put("receiver_user_id",receiverUserId);if(callbackQueryId!=null&&!callbackQueryId.isBlank())ep.put("callback_query_id",callbackQueryId);p.put("ephemeral_message_parameters",Json.stringify(ep)); }
        call("sendMessage",p);
    }
    /** Rich Messages (Bot API 10.1+) with automatic legacy fallback. */
    public void sendRichOrText(long chat,String html,String markup,boolean htmlMode,long receiverUserId,boolean ephemeral,String callbackQueryId)throws Exception{
        try {
            Map<String,Object> rich=new LinkedHashMap<>();rich.put("html",html);rich.put("is_rtl",html.codePoints().anyMatch(x->x>=0x0600&&x<=0x06FF));
            Map<String,Object> p=new LinkedHashMap<>();p.put("chat_id",chat);p.put("rich_message", Json.stringify(rich));if(markup!=null&&!markup.isBlank())p.put("reply_markup",markup);
            if(ephemeral){ Map<String,Object> ep=new LinkedHashMap<>();ep.put("receiver_user_id",receiverUserId);if(callbackQueryId!=null&&!callbackQueryId.isBlank())ep.put("callback_query_id",callbackQueryId);p.put("ephemeral_message_parameters",Json.stringify(ep)); }
            call("sendRichMessage",p);
        } catch(Exception richError){ sendMessage(chat,html,markup,htmlMode,ephemeral?receiverUserId:null,callbackQueryId); }
    }
    public void sendDraft(long chat,long draftId,String text,boolean canStop)throws Exception{call("sendMessageDraft",Map.of("chat_id",chat,"draft_id",draftId,"text",text,"can_stop",canStop,"keep_on_stop",true));}
    public void sendRichDraft(long chat,long draftId,String html,boolean canStop)throws Exception{
        if(chat<0) return;
        Map<String,Object> rich=Map.of("html",html,"is_rtl",html.codePoints().anyMatch(x->x>=0x0600&&x<=0x06FF));
        call("sendRichMessageDraft",Map.of("chat_id",chat,"draft_id",draftId,"rich_message",Json.stringify(rich),"can_stop",canStop));
    }
    public void sendChatAction(long chat,String action)throws Exception{call("sendChatAction",Map.of("chat_id",chat,"action",action));}

    public void editMessage(long chat,long message,String text,String markup)throws Exception{
        Map<String,Object> p=new LinkedHashMap<>();p.put("chat_id",chat);p.put("message_id",message);p.put("text",text);p.put("parse_mode","HTML");if(markup!=null)p.put("reply_markup",markup);call("editMessageText",p);
    }
    public void answerCallback(String id,String text,boolean alert)throws Exception{call("answerCallbackQuery",Map.of("callback_query_id",id,"text",text,"show_alert",alert));}
    public void ban(long c,long u)throws Exception{call("banChatMember",Map.of("chat_id",c,"user_id",u,"revoke_messages",true));}
    public void unban(long c,long u)throws Exception{call("unbanChatMember",Map.of("chat_id",c,"user_id",u,"only_if_banned",true));}
    public void kick(long c,long u)throws Exception{ban(c,u);unban(c,u);}
    public void promote(long c,long u)throws Exception{call("promoteChatMember",Map.of("chat_id",c,"user_id",u,"can_delete_messages",true,"can_restrict_members",true,"can_pin_messages",true,"can_manage_topics",true,"can_invite_users",true));}
    public void setChatMemberTag(long c,long u,String tag)throws Exception{String t=tag==null?"":tag.trim();if(t.length()>16)throw new IllegalArgumentException("Tag must be at most 16 characters");call("setChatMemberTag",Map.of("chat_id",c,"user_id",u,"tag",t));}
    public void demote(long c,long u)throws Exception{call("promoteChatMember",Map.of("chat_id",c,"user_id",u,"can_delete_messages",false,"can_restrict_members",false,"can_pin_messages",false,"can_manage_topics",false,"can_invite_users",false,"can_promote_members",false));}
    public void mute(long c,long u)throws Exception{String perms="{\"can_send_messages\":false,\"can_send_audios\":false,\"can_send_documents\":false,\"can_send_photos\":false,\"can_send_videos\":false,\"can_send_video_notes\":false,\"can_send_voice_notes\":false,\"can_send_polls\":false,\"can_send_other_messages\":false,\"can_add_web_page_previews\":false,\"can_invite_users\":false,\"can_pin_messages\":false,\"can_manage_topics\":false}";call("restrictChatMember",Map.of("chat_id",c,"user_id",u,"permissions",perms,"use_independent_chat_permissions",true));}
    public void unmute(long c,long u)throws Exception{String perms="{\"can_send_messages\":true,\"can_send_audios\":true,\"can_send_documents\":true,\"can_send_photos\":true,\"can_send_videos\":true,\"can_send_video_notes\":true,\"can_send_voice_notes\":true,\"can_send_polls\":true,\"can_send_other_messages\":true,\"can_add_web_page_previews\":true,\"can_invite_users\":true,\"can_pin_messages\":true,\"can_manage_topics\":true}";call("restrictChatMember",Map.of("chat_id",c,"user_id",u,"permissions",perms,"use_independent_chat_permissions",true));}
    public void delete(long c,long m)throws Exception{call("deleteMessage",Map.of("chat_id",c,"message_id",m));}
    public void pin(long c,long m)throws Exception{call("pinChatMessage",Map.of("chat_id",c,"message_id",m,"disable_notification",true));}
    public void unpin(long c,long m)throws Exception{call("unpinChatMessage",Map.of("chat_id",c,"message_id",m));}
    public boolean botCanDelete(long chat)throws Exception{Map<String,Object> m=getChatMember(chat,botId());return "creator".equals(String.valueOf(m.get("status")))||("administrator".equals(String.valueOf(m.get("status")))&&Boolean.TRUE.equals(m.get("can_delete_messages")));}
    public static String urlMarkup(String text,String url){return "{\"inline_keyboard\":[[{\"text\":"+q(text)+",\"web_app\":{\"url\":"+q(url)+"}}]]}";}
    public static String inlineMarkup(String... buttons){StringBuilder b=new StringBuilder("{\"inline_keyboard\":[[");for(int i=0;i<buttons.length;i++){if(i>0)b.append(',');String[]p=buttons[i].split("\\|",2);b.append("{\"text\":").append(q(p[0])).append(",\"callback_data\":").append(q(p.length>1?p[1]:p[0])).append('}');}return b.append("]]}" ).toString();}
    public static String q(String s){return "\""+String.valueOf(s).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\"";}
    private static String encode(Map<String,Object> p){StringBuilder b=new StringBuilder();for(var e:p.entrySet()){if(b.length()>0)b.append('&');b.append(java.net.URLEncoder.encode(e.getKey(),StandardCharsets.UTF_8)).append('=').append(java.net.URLEncoder.encode(String.valueOf(e.getValue()),StandardCharsets.UTF_8));}return b.toString();}
    private static long number(Object x,long d){return x instanceof Number n?n.longValue():d;}
    private static String arrayJson(List<Map<String,String>> l){StringBuilder b=new StringBuilder("[");int i=0;for(var m:l){if(i++>0)b.append(',');b.append('{');int j=0;for(var e:m.entrySet()){if(j++>0)b.append(',');b.append(q(e.getKey())).append(':').append(q(e.getValue()));}String cmd=m.get("command");if(Set.of("panel","settings","logs","perms","reports").contains(cmd))b.append(",\"is_ephemeral\":true");b.append('}');}return b.append(']').toString();}
    public static final class TelegramException extends IOException{public final int code;public final long retryAfter;public TelegramException(String m,int c,long r){super(m);code=c;retryAfter=r;}}
}
