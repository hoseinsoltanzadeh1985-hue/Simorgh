package ir.pedirany.guardian.telegram;

import ir.pedirany.guardian.commands.CommandRouter;
import ir.pedirany.guardian.storage.SupabaseAuditSink;

/** Polling fallback with exponential backoff and optional cross-instance idempotency. */
public final class UpdatePoller {
    private final TelegramClient api;
    private final CommandRouter router;
    private final int timeout;
    private final SupabaseAuditSink cloud;
    private long offset = 0;

    public UpdatePoller(TelegramClient api, CommandRouter router, int timeout) {
        this(api, router, timeout, new SupabaseAuditSink());
    }

    public UpdatePoller(TelegramClient api, CommandRouter router, int timeout, SupabaseAuditSink cloud) {
        this.api = api;
        this.router = router;
        this.timeout = Math.max(1, timeout);
        this.cloud = cloud;
    }

    public void runForever() {
        long backoff = 1000;
        while (!Thread.currentThread().isInterrupted()) {
            try {
                for (Object x : api.getUpdates(offset, timeout)) {
                    var u = Json.obj(x);
                    long updateId = number(u.get("update_id"), offset);
                    offset = Math.max(offset, updateId + 1);
                    if (cloud.enabled()) {
                        boolean claimed;
                        try {
                            claimed = cloud.claimUpdate(updateId);
                        } catch (Exception ex) {
                            if (cloud.required()) throw ex;
                            System.err.println("Supabase idempotency unavailable; using local fallback: " + ex.getMessage());
                            claimed = true;
                        }
                        if (!claimed) continue;
                    }
                    router.handle(u);
                }
                backoff = 1000;
            } catch (TelegramClient.TelegramException e) {
                sleep(e.retryAfter > 0 ? Math.min(30000, e.retryAfter * 1000L) : backoff);
                backoff = Math.min(30000, backoff * 2);
            } catch (Exception e) {
                System.err.println("Update error: " + safe(e));
                sleep(backoff);
                backoff = Math.min(30000, backoff * 2);
            }
        }
    }

    private static long number(Object v, long d) { return v instanceof Number n ? n.longValue() : d; }
    private static String safe(Exception e) { String s = e.getMessage(); return s == null ? e.getClass().getSimpleName() : s; }
    private static void sleep(long ms) { try { Thread.sleep(Math.max(250, ms)); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }
}
