package ir.pedirany.guardian.commands.handlers;

import ir.pedirany.guardian.ai.AiService;
import ir.pedirany.guardian.commands.CommandContext;
import ir.pedirany.guardian.commands.CommandHandler;
import ir.pedirany.guardian.games.GameCenter;
import ir.pedirany.guardian.security.SecurityService;

public final class FeatureHandler {
    private FeatureHandler(){}
    public static CommandHandler ai(AiService ai){return c->{if(!c.security().allowed(c.chatId(),c.userId(),SecurityService.Permission.AI)){deny(c);return;}String p=after(c.text());if(p.isBlank()){c.api().sendMessage(c.chatId(),"استفاده: /ai سؤال");return;}try{if(c.chatId()>0){try{c.api().sendChatAction(c.chatId(),"typing");}catch(Exception ignored){}}String answer=ai.ask(p);c.api().sendMessage(c.chatId(),answer);c.store().audit(c.chatId(),c.userId(),"AI","ok");}catch(Exception e){c.store().audit(c.chatId(),c.userId(),"AI","failed");c.api().sendMessage(c.chatId(),"⚠️ AI موقتاً در دسترس نیست.");}};}
    public static CommandHandler aiStatus(AiService ai){return c->c.api().sendMessage(c.chatId(),"🤖 "+ai.providerSummary());}
    public static CommandHandler game(GameCenter games){return c->games.show(c.chatId(),c.userId(),c.security());}
    public static CommandHandler emoji(){return c->c.api().sendRichOrText(c.chatId(),"😀 <b>Emoji Studio</b>\n📷 یک عکس واضح بفرستید یا روی عکس Reply کنید.\n✨ Crop هوشمند • حذف پس‌زمینه • خروجی شفاف • مجموعه شخصی",null,true,c.userId(),false,"");}
    public static CommandHandler music(){return c->c.api().sendMessage(c.chatId(),"🎵 Media Player جدا از هستهٔ مدیریت است.\n🎙️ Voice Chat در این نسخه عمداً فعال نشده است.");}
    private static String after(String s){int p=s==null?-1:s.indexOf(' ');return p<0?"":s.substring(p+1).trim();}
    private static void deny(CommandContext c)throws Exception{c.api().sendMessage(c.chatId(),"⛔ دسترسی کافی ندارید.");}
}
