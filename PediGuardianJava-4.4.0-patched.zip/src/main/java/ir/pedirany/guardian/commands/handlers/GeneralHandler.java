package ir.pedirany.guardian.commands.handlers;

import ir.pedirany.guardian.commands.CommandContext;
import ir.pedirany.guardian.commands.CommandHandler;
import ir.pedirany.guardian.i18n.I18n;
import ir.pedirany.guardian.panel.GlassPanel;
import ir.pedirany.guardian.security.SecurityService;

public final class GeneralHandler {
    private GeneralHandler() {}
    public static CommandHandler start(I18n i18n) { return c -> {
        var role = c.role();
        if (role == SecurityService.Role.RESTRICTED) { c.api().sendMessage(c.chatId(), "⛔ دسترسی این حساب محدود است."); return; }
        String body = "🛡️ <b>PediGuardian 4.4 Cloud</b>\n☁️ Cloud: Online\n🔐 Security: Active\n👤 Role: " + role;
        c.api().sendRichOrText(c.chatId(), body, GlassPanel.main(role), true, c.userId(), false, "");
    };}
    public static CommandHandler help(I18n i18n) { return c -> c.api().sendRichOrText(c.chatId(), i18n.help(true), null, true, c.userId(), false, ""); }
    public static CommandHandler version() { return c -> c.api().sendRichOrText(c.chatId(), "🛡️ <b>PediGuardian 4.4 Cloud</b>\nRBAC • Webhook • Rich UI • AI • Locks • Reports • Game\n☁️ Supabase Cloud\n🎙️ Voice Chat: جدا/خاموش", null, true, c.userId(), false, ""); }
    public static CommandHandler id() { return c -> c.api().sendMessage(c.chatId(), "🆔 chat_id: <code>"+c.chatId()+"</code>\n👤 user_id: <code>"+c.userId()+"</code>", null, true); }
    public static CommandHandler profile() { return c -> c.api().sendMessage(c.chatId(), "👤 user_id: <code>"+c.userId()+"</code>\nRole: <b>"+c.role()+"</b>", null, true); }
    public static CommandHandler language() { return c -> c.api().sendMessage(c.chatId(), "🌐 فارسی / English فعال است."); }
    public static CommandHandler rules() { return c -> { String r=c.store().rules(c.chatId()); c.api().sendRichOrText(c.chatId(), r.isBlank()?"📜 قانونی ثبت نشده است.":"📜 "+r, null, false, c.userId(), false, ""); }; }
    public static CommandHandler status() { return c -> c.api().sendRichOrText(c.chatId(), "🟢 <b>Cloud Online</b>\n🔐 Security: active\n👤 Role: "+c.role()+"\n🧠 AI gateway ready\n🗄️ Supabase state ready", null, true, c.userId(), false, ""); }
}
