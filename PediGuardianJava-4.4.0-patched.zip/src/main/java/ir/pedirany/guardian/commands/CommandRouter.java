package ir.pedirany.guardian.commands;

import ir.pedirany.guardian.ai.AiService;
import ir.pedirany.guardian.games.GameCenter;
import ir.pedirany.guardian.i18n.I18n;
import ir.pedirany.guardian.music.MusicService;
import ir.pedirany.guardian.panel.GlassPanel;
import ir.pedirany.guardian.security.*;
import ir.pedirany.guardian.storage.StateStore;
import ir.pedirany.guardian.telegram.Json;
import ir.pedirany.guardian.telegram.TelegramClient;
import ir.pedirany.guardian.commands.handlers.*;
import java.util.*;

/** Thin update router. Business logic belongs to focused handlers. */
public final class CommandRouter {
    private final CommandRegistry registry = new CommandRegistry();
    private final TelegramClient api; private final StateStore store; private final SecurityService sec;
    private final RateLimiter limiter; private final I18n i18n; private final LockEngine locks; private final FloodDetector flood;
    private final AiService ai; private final GameCenter games;

    public CommandRouter(TelegramClient api, StateStore store, SecurityService sec, RateLimiter limiter,
                         MusicService music, I18n i18n, String ignoredGameUrl) {
        this.api=api; this.store=store; this.sec=sec; this.limiter=limiter; this.i18n=i18n;
        this.locks=new LockEngine(store); this.flood=new FloodDetector(8,6000); this.ai=new AiService(); this.games=new GameCenter(api); register();
    }
    private void register(){
        registry.register("start",GeneralHandler.start(i18n),"شروع").register("help",GeneralHandler.help(i18n),"راهنما")
            .register("version",GeneralHandler.version(),"نسخه").register("id",GeneralHandler.id(),"آیدی")
            .register("profile",GeneralHandler.profile(),"پروفایل").register("language",GeneralHandler.language(),"زبان")
            .register("rules",GeneralHandler.rules(),"قوانین").register("status",GeneralHandler.status(),"وضعیت")
            .register("panel",GeneralHandler.start(i18n),"پنل","پنل_مدیریت")
            .register("warn",ModerationHandler.warn(),"اخطار").register("warnings",ModerationHandler.warnings(),"اخطارها")
            .register("clearwarnings",ModerationHandler.clearWarnings(),"پاک_اخطار").register("setwarninglimit",ModerationHandler.setWarningLimit(),"حد_اخطار")
            .register("mute",ModerationHandler.mute(),"سکوت").register("unmute",ModerationHandler.unmute(),"رفع_سکوت")
            .register("ban",ModerationHandler.ban(),"مسدود").register("unban",ModerationHandler.unban(),"رفع_مسدودی")
            .register("kick",ModerationHandler.kick(),"اخراج").register("del",ModerationHandler.del(),"حذف")
            .register("pin",ModerationHandler.pin(),"پین").register("unpin",ModerationHandler.unpin(),"برداشتن_پین")
            .register("lock",SecurityHandler.lock(true),"قفل").register("unlock",SecurityHandler.lock(false),"بازکردن")
            .register("locks",SecurityHandler.locks(),"قفلها").register("security",SecurityHandler.security(),"امنیت")
            .register("antiraid",SecurityHandler.antiraid(),"ضد_حمله").register("admins",SecurityHandler.admins(),"مدیران")
            .register("addadmin",SecurityHandler.addAdmin(true),"افزودن_مدیر").register("removeadmin",SecurityHandler.addAdmin(false),"حذف_مدیر")
            .register("grantperm",SecurityHandler.permissions(true),"اعطای_دسترسی").register("revokeperm",SecurityHandler.permissions(false),"لغو_دسترسی")
            .register("perms",SecurityHandler.perms(),"دسترسیها").register("logs",SecurityHandler.logs(),"لاگ")
            .register("settings",SecurityHandler.settings(),"تنظیمات").register("setrules",SecurityHandler.setRules(),"تنظیم_قوانین")
            .register("welcome",SecurityHandler.welcome(),"خوشامد").register("setwelcome",SecurityHandler.setWelcome(),"تنظیم_خوشامد")
            .register("filter",SecurityHandler.filter(),"فیلتر").register("filters",SecurityHandler.filters(),"فیلترها")
            .register("badword",SecurityHandler.badword(),"کلمه_بد").register("badwords",SecurityHandler.badwords(),"کلمات_بد")
            .register("settag",SecurityHandler.setTag(),"برچسب")
            .register("ai",FeatureHandler.ai(ai),"هوش","هوش_مصنوعی").register("aistatus",FeatureHandler.aiStatus(ai),"وضعیت_هوش")
            .register("game",FeatureHandler.game(games),"بازی","بازیها").register("emoji",FeatureHandler.emoji(),"ایموجی")
            .register("play",FeatureHandler.music(),"پخش").register("pause",FeatureHandler.music(),"مکث")
            .register("resume",FeatureHandler.music(),"ادامه").register("skip",FeatureHandler.music(),"بعدی")
            .register("stop",FeatureHandler.music(),"توقف").register("queue",FeatureHandler.music(),"صف");
    }
    public void handle(Map<String,Object> update){
        try {
            if(update==null)return;
            if(update.containsKey("callback_query")){callback(Json.obj(update.get("callback_query")));return;}
            if(update.containsKey("chat_member")){memberUpdate(Json.obj(update.get("chat_member")));return;}
            if(update.containsKey("my_chat_member")){botMembershipUpdate(Json.obj(update.get("my_chat_member")));return;}
            Object raw=update.get("message"); if(raw==null)raw=update.get("edited_message"); if(raw==null)return;
            Map<String,Object> msg=Json.obj(raw),chat=Json.obj(msg.get("chat")),from=Json.obj(msg.get("from")); long cid=num(chat.get("id"),0),uid=num(from.get("id"),0),mid=num(msg.get("message_id"),0);
            if(!limiter.allow(cid,uid))return;
            String text=string(msg.getOrDefault("text",msg.getOrDefault("caption",""))).trim();
            if(text.startsWith("/")){CommandHandler h=registry.resolve(text);if(h!=null)h.handle(new CommandContext(api,store,sec,cid,uid,mid,text,msg));return;}
            inspectMessage(cid,uid,mid,text,msg);
        } catch(Exception e){System.err.println("Command router error: "+safe(e));}
    }
    private void callback(Map<String,Object> q)throws Exception{
        String id=string(q.get("id"));Map<String,Object> from=Json.obj(q.get("from")),msg=Json.obj(q.get("message")),chat=Json.obj(msg.get("chat"));long user=num(from.get("id"),0),cid=num(chat.get("id"),0),mid=num(msg.get("message_id"),0);String d=string(q.get("data"));SecurityService.Role role=sec.role(cid,user);
        if("p:main".equals(d)){api.answerCallback(id,"✅",false);api.editMessage(cid,mid,"🪟 <b>Simorgh Cloud Center</b>\n👤 "+role,GlassPanel.main(role));return;}
        if(d.startsWith("p:")){String page=d.substring(2);SecurityService.Permission needed=switch(page){case "members","mod"->SecurityService.Permission.MODERATION;case "security","reports"->SecurityService.Permission.REPORTS;case "locks"->SecurityService.Permission.LOCKS;case "roles","settings"->SecurityService.Permission.ADMINS;default->SecurityService.Permission.AI;};if(!sec.allowed(cid,user,needed)){api.answerCallback(id,"⛔ دسترسی ندارید",true);return;}api.answerCallback(id,"✅",false);api.editMessage(cid,mid,"🪟 <b>"+page+"</b>",GlassPanel.section(page,role));return;}
        if(d.startsWith("l:")){if(!sec.allowed(cid,user,SecurityService.Permission.LOCKS)){api.answerCallback(id,"⛔",true);return;}String lt=d.substring(2);boolean on=!store.lock(cid,lt);store.setLock(cid,lt,on);store.audit(cid,user,on?"LOCK_ON":"LOCK_OFF",lt);api.answerCallback(id,on?"🔒 ON":"🔓 OFF",false);return;}
        if(d.startsWith("theme:")){String t=d.substring(6);if(Set.of("midnight","ocean","emerald","light").contains(t)){store.setPreference(cid,user,"theme",t);store.audit(cid,user,"THEME",t);api.answerCallback(id,"🎨 "+t,false);}else api.answerCallback(id,"Invalid",true);return;}
        if("a:game".equals(d)){games.show(cid,user,sec);api.answerCallback(id,"🎮",false);return;}
        if("a:aistatus".equals(d)){api.answerCallback(id,"🤖 "+ai.providerSummary(),true);return;}
        if("a:ai".equals(d)){api.answerCallback(id,"💬 برای استفاده /ai سؤال را بفرستید.",true);return;}
        if("a:emoji".equals(d)){api.answerCallback(id,"📷 برای ایموجی روی عکس Reply کنید و /emoji را بزنید.",true);return;}
        if("a:emojihelp".equals(d)){api.answerCallback(id,"📷 عکس را Reply کنید؛ سپس /emoji را اجرا کنید.",true);return;}
        if("a:admins".equals(d)){StringBuilder b=new StringBuilder("👮 <b>Administrators</b>\n");for(Object o:api.getChatAdministrators(cid)){var a=Json.obj(o);var u=Json.obj(a.get("user"));b.append("• ").append(escapeHtml(String.valueOf(u.getOrDefault("first_name","User")))).append(" <code>").append(String.valueOf(u.getOrDefault("id",""))).append("</code>\n");}api.sendMessage(cid,b.toString(),null,true);api.answerCallback(id,"✅",false);return;}
        if("a:warnings".equals(d)){api.sendMessage(cid,"⚠️ <b>Warnings</b>\nبرای مشاهده/مدیریت اخطار یک پیام کاربر را Reply کنید و /warnings یا /clearwarnings بفرستید.",null,true);api.answerCallback(id,"✅",false);return;}
        if(Set.of("a:warn","a:mute","a:ban","a:delete","a:pin","a:purge").contains(d)){String cmd=d.substring(2);String hint=switch(cmd){case "delete"->"/del";case "warn","mute","ban","pin"->"/"+cmd;default->"/purge";};api.sendMessage(cid,"🛠️ این عملیات آماده است.\nروی پیام هدف Reply کنید و «"+hint+"» را بزنید.",null,false);api.answerCallback(id,"✅",false);return;}
        if("a:antiraid".equals(d)){SecurityHandler.antiraid().handle(new CommandContext(api,store,sec,cid,user,mid,"/antiraid",Map.of()));api.answerCallback(id,"✅",false);return;}
        if("a:antispam".equals(d)){api.sendMessage(cid,"🛡️ Anti-spam در هسته فعال است؛ Flood detector نیز فعال است.");api.answerCallback(id,"✅",false);return;}
        if("a:antilink".equals(d)){boolean on=!store.lock(cid,"links");store.setLock(cid,"links",on);store.audit(cid,user,on?"ANTILINK_ON":"ANTILINK_OFF","links");api.sendMessage(cid,on?"🔗 Anti-link فعال شد.":"🔓 Anti-link غیرفعال شد.");api.answerCallback(id,on?"🔗 ON":"🔓 OFF",false);return;}
        if("a:security".equals(d)){api.sendMessage(cid,"🛡️ <b>Security</b>\n✅ Role hierarchy\n✅ Native Telegram rights\n✅ Rate/Flood control\n✅ Locks\n✅ Audit\n✅ Dynamic bad-word policy",null,true);api.answerCallback(id,"✅",false);return;}
        if("a:scores".equals(d)){api.sendMessage(cid,"🏆 هنوز رکوردی ثبت نشده است. بازی Air Raider آماده است.");api.answerCallback(id,"🏆",false);return;}
        if("a:reports".equals(d)){api.sendMessage(cid,store.dump().isBlank()?"📊 گزارشی ثبت نشده.":"📊 <b>Audit / Reports</b>\n"+store.dump(),null,true);api.answerCallback(id,"✅",false);return;}
        if("a:logs".equals(d)){String v=store.dump();api.sendMessage(cid,v.isBlank()?"📜 لاگی ثبت نشده.":"📜 <b>Audit Log</b>\n"+v,null,true);api.answerCallback(id,"✅",false);return;}
        if("a:rules".equals(d)){api.sendMessage(cid,store.rules(cid).isBlank()?"📜 قوانینی ثبت نشده.":"📜 <b>Rules</b>\n"+escapeHtml(store.rules(cid)),null,true);api.answerCallback(id,"✅",false);return;}
        if("a:welcome".equals(d)){String v=store.welcome(cid);api.sendMessage(cid,v.isBlank()?"👋 خوشامد تنظیم نشده.":"👋 "+escapeHtml(v),null,true);api.answerCallback(id,"✅",false);return;}
        if("a:filters".equals(d)){var m=store.filters(cid);StringBuilder b=new StringBuilder("🧩 <b>Filters</b>\n");if(m.isEmpty())b.append("موردی ثبت نشده.");else m.forEach((k,v)->b.append("• ").append(escapeHtml(k)).append(" → ").append(escapeHtml(v)).append('\n'));api.sendMessage(cid,b.toString(),null,true);api.answerCallback(id,"✅",false);return;}
        if("a:notes".equals(d)){var m=store.notes(cid);StringBuilder b=new StringBuilder("📌 <b>Notes</b>\n");if(m.isEmpty())b.append("یادداشتی ثبت نشده.");else m.forEach((k,v)->b.append("• ").append(escapeHtml(k)).append(" → ").append(escapeHtml(v)).append('\n'));api.sendMessage(cid,b.toString(),null,true);api.answerCallback(id,"✅",false);return;}
        if("a:language".equals(d)){api.answerCallback(id,"🌐 فارسی / English",true);return;}
        if("a:perms".equals(d)){api.sendMessage(cid,"🔐 برای نمایش دسترسی یک کاربر، روی پیام او Reply کنید و /perms را اجرا کنید.");api.answerCallback(id,"✅",false);return;}
        if("a:senior".equals(d)){api.sendMessage(cid,"⭐ Senior Admin\nاین نقش باید توسط Bot Owner/مدیر مجاز تنظیم شود.");api.answerCallback(id,"✅",false);return;}
        api.answerCallback(id,"ℹ️ این بخش آماده شده؛ برای اجرای عملیات هدفمند از دستور متناظر استفاده کنید.",true);
    }
    private void memberUpdate(Map<String,Object> u)throws Exception{Map<String,Object> chat=Json.obj(u.get("chat")),nm=Json.obj(u.get("new_chat_member"));long c=num(chat.get("id"),0),uid=num(Json.obj(nm.get("user")).get("id"),0);String st=string(nm.getOrDefault("status",""));if("administrator".equals(st))store.setRole(c,uid,"ADMIN");if(("member".equals(st)||"restricted".equals(st))&&!store.welcome(c).isBlank()){api.sendMessage(c,store.welcome(c).replace("{user}","<a href=\"tg://user?id="+uid+"\">عضو جدید</a>"),null,true);}}
    private void botMembershipUpdate(Map<String,Object> u){Map<String,Object> chat=Json.obj(u.get("chat")),nm=Json.obj(u.get("new_chat_member"));String st=string(nm.getOrDefault("status",""));if("kicked".equals(st)||"left".equals(st))System.err.println("Bot removed from chat "+num(chat.get("id"),0));}
    private void inspectMessage(long chat,long user,long message,String text,Map<String,Object> msg)throws Exception{
        if(flood.hit(chat,user)){autoDelete(chat,message,"AUTO_FLOOD");return;}
        String lock=locks.detect(chat,msg); if(lock!=null){autoDelete(chat,message,"LOCK_"+lock);return;}
        String lower=text.toLowerCase(Locale.ROOT);if(store.lock(chat,"badwords")&&store.badwords(chat).stream().anyMatch(w->!w.isBlank()&&lower.contains(w.toLowerCase(Locale.ROOT)))){autoDelete(chat,message,"LOCK_badwords");return;}
        if(store.lock(chat,"keyboards")&&msg.containsKey("reply_markup")){autoDelete(chat,message,"LOCK_keyboards");return;}
        if(store.lock(chat,"anonchannel")&&msg.containsKey("sender_chat")){autoDelete(chat,message,"LOCK_anonchannel");return;}
        for(var e:store.filters(chat).entrySet())if(!e.getKey().isBlank()&&lower.contains(e.getKey().toLowerCase(Locale.ROOT))){api.sendMessage(chat,e.getValue());break;}
    }
    private void autoDelete(long chat,long message,String action){try{if(api.botCanDelete(chat)){api.delete(chat,message);store.audit(chat,0,action,"deleted");}}catch(Exception ignored){}}
    private static String escapeHtml(String s){return String.valueOf(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
    private static long num(Object x,long d){return x instanceof Number n?n.longValue():d;} private static String string(Object x){return x==null?"":String.valueOf(x);} private static String safe(Exception e){return e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();}
}
