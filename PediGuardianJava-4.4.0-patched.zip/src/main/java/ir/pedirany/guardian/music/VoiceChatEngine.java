package ir.pedirany.guardian.music;

public interface VoiceChatEngine extends AutoCloseable {
    void play(long chatId, String source) throws Exception;
    void pause(long chatId) throws Exception;
    void resume(long chatId) throws Exception;
    void stop(long chatId) throws Exception;
    default void join(long chatId) throws Exception { }
    @Override default void close() throws Exception { }
}
