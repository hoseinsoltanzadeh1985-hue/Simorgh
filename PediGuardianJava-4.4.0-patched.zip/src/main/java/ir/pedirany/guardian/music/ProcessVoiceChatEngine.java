package ir.pedirany.guardian.music;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/** Java controller for the real MTProto/WebRTC voice engine sidecar. */
public final class ProcessVoiceChatEngine implements VoiceChatEngine {
    private final Process process;
    private final BufferedWriter in;
    private final BufferedReader out;
    private final long timeoutSeconds;

    public ProcessVoiceChatEngine(String command, long timeoutSeconds) throws IOException {
        this.timeoutSeconds = timeoutSeconds;
        this.process = new ProcessBuilder("sh", "-lc", command)
                .redirectError(ProcessBuilder.Redirect.INHERIT).start();
        this.in = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
        this.out = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
    }

    private synchronized void request(String op, long chatId, String source) throws Exception {
        String json = "{\"op\":" + q(op) + ",\"chat_id\":" + chatId + (source == null ? "" : ",\"source\":" + q(source)) + "}";
        in.write(json); in.newLine(); in.flush();
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(timeoutSeconds);
        while (System.nanoTime() < deadline) {
            if (out.ready()) {
                String line = out.readLine();
                if (line == null) throw new IOException("Voice engine exited");
                if (!line.contains("\"ok\":true")) throw new IOException("Voice engine: " + line);
                return;
            }
            Thread.sleep(25);
        }
        throw new IOException("Voice engine timeout: " + op);
    }
    private static String q(String s){ return "\"" + s.replace("\\","\\\\").replace("\"","\\\"") + "\""; }
    public void play(long c,String s)throws Exception{request("play",c,s);}
    public void pause(long c)throws Exception{request("pause",c,null);}
    public void resume(long c)throws Exception{request("resume",c,null);}
    public void stop(long c)throws Exception{request("stop",c,null);}
    public void join(long c)throws Exception{request("join",c,null);}
    public void close() throws Exception { try { process.destroy(); process.waitFor(3,TimeUnit.SECONDS); } finally { process.destroyForcibly(); } }
}
