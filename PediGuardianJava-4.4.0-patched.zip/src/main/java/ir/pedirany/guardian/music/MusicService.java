package ir.pedirany.guardian.music;
import java.util.*; import java.util.concurrent.ConcurrentHashMap;
public final class MusicService implements AutoCloseable {
 private final Map<Long,Deque<Track>> queues=new ConcurrentHashMap<>();
 private final VoiceChatEngine engine;
 public MusicService(VoiceChatEngine engine){this.engine=engine;}
 public synchronized void enqueue(long chat,String title,String source){queues.computeIfAbsent(chat,k->new ArrayDeque<>()).addLast(new Track(title,source));}
 public synchronized Track next(long chat){var q=queues.get(chat);return q==null?null:q.pollFirst();}
 public synchronized List<Track> queue(long chat){var q=queues.get(chat);return q==null?List.of():List.copyOf(q);}
 public void play(long chat,Track t)throws Exception{engine.play(chat,t.source());}
 public void pause(long chat)throws Exception{engine.pause(chat);} public void resume(long chat)throws Exception{engine.resume(chat);} public void stop(long chat)throws Exception{engine.stop(chat);}
 public record Track(String title,String source){}
 public void close() throws Exception{engine.close();}
}
