package ir.pedirany.guardian.commands.handlers;

import ir.pedirany.guardian.commands.CommandContext;
import ir.pedirany.guardian.commands.CommandHandler;
import ir.pedirany.guardian.security.SecurityService;

/** Focused moderation handlers. Every target action re-checks live authorization. */
public final class ModerationHandler {
    private ModerationHandler() {}

    public static CommandHandler warn() {
        return c -> {
            Long target = c.replyUserId();
            if (target == null) { promptReply(c); return; }
            if (!c.security().canTarget(c.chatId(), c.userId(), target, SecurityService.Permission.WARN)) {
                deny(c, "⛔ سطح دسترسی یا مجوز Telegram کافی نیست."); return;
            }
            int n = c.store().addWarning(c.chatId(), target);
            int limit = c.store().warningLimit(c.chatId());
            c.api().sendMessage(c.chatId(), "⚠️ اخطار ثبت شد: " + n + "/" + limit);
            if (n >= limit && c.security().canTarget(c.chatId(), c.userId(), target, SecurityService.Permission.MUTE)) {
                c.api().mute(c.chatId(), target);
                c.store().setMemberStatus(c.chatId(), target, "muted");
                c.api().sendMessage(c.chatId(), "🔇 حد اخطار رسید؛ کاربر محدود شد.");
            }
        };
    }

    public static CommandHandler warnings() {
        return withUserTarget(c -> c.api().sendMessage(c.chatId(),
                "⚠️ تعداد اخطار: " + c.store().warnings(c.chatId(), c.replyUserId())));
    }

    public static CommandHandler clearWarnings() {
        return withUserTarget(c -> {
            c.store().clearWarnings(c.chatId(), c.replyUserId());
            c.api().sendMessage(c.chatId(), "✅ اخطارها پاک شد.");
        });
    }

    public static CommandHandler setWarningLimit() {
        return c -> {
            if (!c.security().allowed(c.chatId(), c.userId(), SecurityService.Permission.SETTINGS)) {
                deny(c); return;
            }
            try {
                int n = Integer.parseInt(after(c.text()));
                if (n < 1 || n > 20) throw new NumberFormatException();
                c.store().setWarningLimit(c.chatId(), n);
                c.api().sendMessage(c.chatId(), "✅ حد اخطار: " + c.store().warningLimit(c.chatId()));
            } catch (Exception e) {
                c.api().sendMessage(c.chatId(), "استفاده: /setwarninglimit 1-20");
            }
        };
    }

    public static CommandHandler mute() {
        return userModeration(SecurityService.Permission.MUTE, "🔇 کاربر محدود شد.",
                (c, target) -> { c.api().mute(c.chatId(), target); c.store().setMemberStatus(c.chatId(), target, "muted"); });
    }

    public static CommandHandler unmute() {
        return userModeration(SecurityService.Permission.MUTE, "🔊 محدودیت برداشته شد.",
                (c, target) -> { c.api().unmute(c.chatId(), target); c.store().setMemberStatus(c.chatId(), target, "active"); });
    }

    public static CommandHandler ban() {
        return userModeration(SecurityService.Permission.BAN, "🚫 کاربر مسدود شد.",
                (c, target) -> { c.api().ban(c.chatId(), target); c.store().setMemberStatus(c.chatId(), target, "banned"); });
    }

    public static CommandHandler unban() {
        return c -> {
            Long target = c.replyUserId();
            if (target == null) { promptReply(c); return; }
            if (!c.security().canTarget(c.chatId(), c.userId(), target, SecurityService.Permission.BAN)) {
                deny(c, "⛔ سطح دسترسی یا مجوز Telegram کافی نیست."); return;
            }
            c.api().unban(c.chatId(), target);
            c.store().setMemberStatus(c.chatId(), target, "active");
            c.api().sendMessage(c.chatId(), "✅ مسدودی برداشته شد.");
        };
    }

    public static CommandHandler kick() {
        return userModeration(SecurityService.Permission.BAN, "👢 کاربر اخراج شد.",
                (c, target) -> c.api().kick(c.chatId(), target));
    }

    public static CommandHandler del() { return messageAction(SecurityService.Permission.DELETE, "🗑️ حذف شد.", (c,m)->c.api().delete(c.chatId(),m)); }
    public static CommandHandler pin() { return messageAction(SecurityService.Permission.PIN, "📌 پین شد.", (c,m)->c.api().pin(c.chatId(),m)); }
    public static CommandHandler unpin() { return messageAction(SecurityService.Permission.PIN, "📍 پین برداشته شد.", (c,m)->c.api().unpin(c.chatId(),m)); }

    private static CommandHandler userModeration(SecurityService.Permission p, String success, TargetAction action) {
        return c -> {
            Long target = c.replyUserId();
            if (target == null) { promptReply(c); return; }
            if (!c.security().canTarget(c.chatId(), c.userId(), target, p)) {
                deny(c, "⛔ سطح دسترسی یا مجوز Telegram کافی نیست."); return;
            }
            action.run(c, target);
            c.api().sendMessage(c.chatId(), success);
        };
    }

    private static CommandHandler withUserTarget(TargetHandler handler) {
        return c -> {
            if (c.replyUserId() == null) { promptReply(c); return; }
            handler.run(c);
        };
    }

    private static CommandHandler messageAction(SecurityService.Permission p, String success, MessageAction action) {
        return c -> {
            Long message = c.replyMessageId();
            if (message == null) { c.api().sendMessage(c.chatId(), "⚠️ روی پیام Reply کنید."); return; }
            if (!c.security().allowed(c.chatId(), c.userId(), p)) { deny(c); return; }
            action.run(c, message);
            c.api().sendMessage(c.chatId(), success);
        };
    }

    private static void promptReply(CommandContext c) throws Exception { c.api().sendMessage(c.chatId(), "⚠️ روی پیام کاربر Reply کنید."); }
    private static void deny(CommandContext c) throws Exception { deny(c, "⛔ دسترسی کافی ندارید."); }
    private static void deny(CommandContext c, String message) throws Exception { c.api().sendMessage(c.chatId(), message); }
    private static String after(String s) { int p = s == null ? -1 : s.indexOf(' '); return p < 0 ? "" : s.substring(p + 1).trim(); }

    @FunctionalInterface private interface TargetAction { void run(CommandContext c, long target) throws Exception; }
    @FunctionalInterface private interface MessageAction { void run(CommandContext c, long message) throws Exception; }
    @FunctionalInterface private interface TargetHandler { void run(CommandContext c) throws Exception; }
}
