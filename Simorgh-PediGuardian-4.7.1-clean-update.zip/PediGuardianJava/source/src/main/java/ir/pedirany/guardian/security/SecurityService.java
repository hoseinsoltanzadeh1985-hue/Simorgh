package ir.pedirany.guardian.security;

import ir.pedirany.guardian.storage.StateStore;
import ir.pedirany.guardian.telegram.TelegramClient;
import java.util.*;

/** Defense-in-depth authorization: persisted role is advisory; live Telegram rights and target hierarchy are authoritative. */
public final class SecurityService {
    public enum Role {
        RESTRICTED, MEMBER, HELPER, MODERATOR, ADMIN, SENIOR_ADMIN, GROUP_OWNER, BOT_OWNER;
        public boolean atLeast(Role r) { return ordinal() >= r.ordinal(); }
        public static Role parse(String s) { try { return valueOf(String.valueOf(s).toUpperCase(Locale.ROOT)); } catch (Exception e) { return MEMBER; } }
    }

    public enum Permission {
        WARN, MUTE, BAN, DELETE, MODERATION, LOCKS, ADMINS, REPORTS, SETTINGS, WELCOME,
        AI, GAME, PIN, TAG, NOTES, FILTERS, ANTIRAID, HELPER, EMOJI, MUSIC, VOICE_TOOLS
    }

    private final TelegramClient api;
    private final StateStore store;
    private final long botOwner;

    public SecurityService(TelegramClient api, StateStore store, long botOwner) {
        this.api = api; this.store = store; this.botOwner = botOwner;
    }

    public long botOwnerId() { return botOwner; }

    public Role role(long chat, long user) throws Exception {
        if (botOwner != 0 && user == botOwner) return Role.BOT_OWNER;
        if (chat == user) return Role.MEMBER;
        Map<String,Object> member = api.getChatMember(chat, user);
        String status = str(member.getOrDefault("status", "member"));
        if ("creator".equals(status)) return Role.GROUP_OWNER;
        Role saved = Role.parse(store.role(chat, user));
        if ("administrator".equals(status)) {
            return saved == Role.SENIOR_ADMIN ? Role.SENIOR_ADMIN : Role.ADMIN;
        }
        if ("restricted".equals(status) || "left".equals(status) || "kicked".equals(status) || "banned".equalsIgnoreCase(store.memberStatus(chat, user))) {
            return Role.RESTRICTED;
        }
        return switch (saved) { case HELPER, MODERATOR -> saved; default -> Role.MEMBER; };
    }

    public boolean allowed(long chat, long user, Permission p) throws Exception {
        Role r = role(chat, user);
        if (r == Role.RESTRICTED || !r.atLeast(floor(p))) return false;
        if (p == Permission.AI || p == Permission.GAME || p == Permission.EMOJI || p == Permission.MUSIC) return true;
        if (chat == user) return false;
        if (!botHasNativePermission(chat, p)) return false;
        // Custom permissions are additive, never a substitute for the base role floor.
        return r.atLeast(floor(p)) || store.permission(chat, user, p.name());
    }

    public boolean canTarget(long chat, long actor, long target, Permission p) throws Exception {
        if (target <= 0 || actor == target || !allowed(chat, actor, p)) return false;
        if (target == botOwner && botOwner != 0) return false;
        Role ar = role(chat, actor), tr = role(chat, target);
        if (tr == Role.GROUP_OWNER || tr == Role.BOT_OWNER) return false;
        return ar == Role.BOT_OWNER || tr.ordinal() < ar.ordinal();
    }

    public boolean telegramCanAct(long chat, long actor, long target, Permission p) throws Exception {
        return canTarget(chat, actor, target, p);
    }

    public boolean protectedUser(long chat, long target) throws Exception {
        if (target <= 0) return true;
        if (target == botOwner && botOwner != 0) return true;
        Map<String,Object> m = api.getChatMember(chat, target);
        String status = str(m.getOrDefault("status", "member"));
        return "creator".equals(status) || "administrator".equals(status);
    }

    public boolean canManageAdmins(long chat, long actor) throws Exception {
        return role(chat, actor).atLeast(Role.SENIOR_ADMIN) && botHasNativePermission(chat, Permission.ADMINS);
    }

    public boolean canManageTags(long chat, long actor) throws Exception {
        return role(chat, actor).atLeast(Role.SENIOR_ADMIN) && botHasNativePermission(chat, Permission.TAG);
    }

    private Role floor(Permission p) {
        return switch (p) {
            case AI, GAME, EMOJI, MUSIC -> Role.MEMBER;
            case VOICE_TOOLS -> Role.MODERATOR;
            case HELPER -> Role.HELPER;
            case MODERATION, WARN, MUTE, DELETE -> Role.MODERATOR;
            case BAN, PIN, LOCKS, REPORTS, WELCOME, FILTERS, ANTIRAID -> Role.ADMIN;
            case ADMINS, SETTINGS, NOTES, TAG -> Role.SENIOR_ADMIN;
        };
    }

    private boolean botHasNativePermission(long chat, Permission p) throws Exception {
        Map<String,Object> me = api.getMe();
        long botId = number(me.get("id"), 0);
        if (botId == 0) return false;
        Map<String,Object> bot = api.getChatMember(chat, botId);
        String status = str(bot.getOrDefault("status", "member"));
        if ("creator".equals(status)) return true;
        if (!"administrator".equals(status)) return false;
        return switch (p) {
            case DELETE -> bool(bot, "can_delete_messages");
            case WARN, MUTE, BAN -> bool(bot, "can_restrict_members");
            case PIN -> bool(bot, "can_pin_messages");
            case ADMINS -> bool(bot, "can_promote_members");
            case TAG -> bool(bot, "can_manage_tags");
            case WELCOME -> bool(bot, "can_send_welcome_messages");
            case SETTINGS, FILTERS, LOCKS, ANTIRAID -> bool(bot, "can_change_info") || bool(bot, "can_manage_chat");
            case REPORTS, NOTES, MODERATION, HELPER, AI, GAME, EMOJI, MUSIC, VOICE_TOOLS -> true;
        };
    }

    private static boolean bool(Map<String,Object> m, String k) { return Boolean.TRUE.equals(m.get(k)); }
    private static long number(Object v, long d) { return v instanceof Number n ? n.longValue() : d; }
    private static String str(Object v) { return v == null ? "" : String.valueOf(v); }
}
