package ir.pedirany.guardian.core;

import java.net.URI;

/** Validated runtime configuration. Secrets are read only from the process environment. */
public record Config(
        String token, long botOwnerId, int pollTimeout, int rateLimitPerMinute,
        String dataFile, String deploymentMode, String gameUrl, boolean strictStartup,
        String supabaseUrl, String supabaseKey, boolean supabaseRequired) {

    public static Config fromEnv() {
        String token = env("BOT_TOKEN", "");
        requireToken(token);

        String mode = env("DEPLOYMENT_MODE", "cloud").toLowerCase();
        if (!mode.equals("local") && !mode.equals("cloud") && !mode.equals("hybrid")) {
            throw new IllegalStateException("DEPLOYMENT_MODE must be local, cloud or hybrid");
        }

        int pollTimeout = boundedInt("POLL_TIMEOUT_SECONDS", 30, 1, 50);
        int rateLimit = boundedInt("RATE_LIMIT_PER_MINUTE", 30, 1, 1000);

        String url = env("SUPABASE_URL", "");
        String key = env("SUPABASE_SECRET_KEY", env("SUPABASE_SERVICE_ROLE_KEY", ""));
        if (!url.isBlank()) requireHttpsUrl(url, "SUPABASE_URL");
        boolean required = boolEnv("SUPABASE_REQUIRED", false);
        if (required && (url.isBlank() || key.isBlank())) {
            throw new IllegalStateException("SUPABASE_URL and server-only Supabase key are required");
        }
        if (!key.isBlank()) requireSecretShape(key, "SUPABASE_SECRET_KEY");

        String gameUrl = env("GAME_URL", "");
        if (!gameUrl.isBlank()) requireHttpsUrl(gameUrl, "GAME_URL");
        String dataFile = env("DATA_FILE", "data/state.properties");
        if (dataFile.length() > 400 || dataFile.contains("\u0000")) {
            throw new IllegalStateException("DATA_FILE is invalid");
        }

        return new Config(token, longEnvStrict("BOT_OWNER_ID", 0), pollTimeout, rateLimit,
                dataFile, mode, gameUrl, boolEnv("STRICT_STARTUP", false),
                url, key, required);
    }

    private static void requireToken(String token) {
        if (token.isBlank() || token.length() > 256 || !token.matches("\\d{6,12}:[A-Za-z0-9_-]{20,200}")) {
            throw new IllegalStateException("BOT_TOKEN format is invalid");
        }
    }

    private static void requireHttpsUrl(String value, String name) {
        try {
            URI u = URI.create(value);
            if (!"https".equalsIgnoreCase(u.getScheme()) || u.getHost() == null || u.getUserInfo() != null) {
                throw new IllegalArgumentException();
            }
        } catch (Exception e) {
            throw new IllegalStateException(name + " must be a valid HTTPS URL");
        }
    }

    private static void requireSecretShape(String value, String name) {
        if (value.length() < 16 || value.length() > 1024 || value.chars().anyMatch(Character::isWhitespace)) {
            throw new IllegalStateException(name + " is invalid");
        }
    }

    private static String env(String k, String d) {
        String v = System.getenv(k);
        return v == null || v.isBlank() ? d : v.trim();
    }

    private static int boundedInt(String k, int d, int min, int max) {
        try { int v = Integer.parseInt(env(k, String.valueOf(d))); if (v < min || v > max) throw new IllegalStateException(k + " out of range"); return v; }
        catch (NumberFormatException e) { throw new IllegalStateException(k + " must be an integer"); }
    }

    private static long boundedLong(String k, long d, long min, long max) {
        try { long v = Long.parseLong(env(k, String.valueOf(d))); if (v < min || v > max) throw new IllegalStateException(k + " out of range"); return v; }
        catch (NumberFormatException e) { throw new IllegalStateException(k + " must be an integer"); }
    }

    private static long longEnvStrict(String k, long d) {
        String v = env(k, String.valueOf(d));
        try { long n = Long.parseLong(v); if (n < 0) throw new IllegalStateException(k + " must be non-negative"); return n; }
        catch (NumberFormatException e) { throw new IllegalStateException(k + " must be an integer"); }
    }

    private static boolean boolEnv(String k, boolean d) {
        String v = env(k, String.valueOf(d));
        return switch (v.toLowerCase()) { case "1", "true", "yes" -> true; case "0", "false", "no" -> false; default -> throw new IllegalStateException(k + " must be boolean"); };
    }
}
