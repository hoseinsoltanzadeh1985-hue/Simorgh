package ir.pedirany.guardian.commands;

import java.util.*;

/** Explicit command registry; aliases are kept separate from handler ownership. */
public final class CommandRegistry {
    private final Map<String, CommandHandler> handlers = new HashMap<>();
    private final Map<String, String> aliases = new HashMap<>();

    public CommandRegistry register(String command, CommandHandler handler, String... aliases) {
        handlers.put(command, handler);
        this.aliases.put('/' + command, command);
        for (String alias : aliases) this.aliases.put('/' + alias, command);
        return this;
    }
    public CommandHandler resolve(String raw) {
        String command = normalize(raw);
        String key = aliases.get(command);
        return key == null ? null : handlers.get(key);
    }
    public String commandKey(String raw) {
        return aliases.get(normalize(raw));
    }
    public Set<String> commandKeys() { return Collections.unmodifiableSet(handlers.keySet()); }
    public static String normalize(String raw) {
        if (raw == null) return "";
        String token = raw.trim().split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        int at = token.indexOf('@');
        return at > 0 ? token.substring(0, at) : token;
    }
}
