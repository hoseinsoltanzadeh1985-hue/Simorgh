package ir.pedirany.guardian.security;
import ir.pedirany.guardian.storage.StateStore;
import java.util.*;
public final class LockEngine{
 private final StateStore store; public LockEngine(StateStore s){store=s;}
 public String detect(long chat,Map<String,Object> m){
  if(m==null)return null;List<String> c=new ArrayList<>();
  if(m.containsKey("photo"))c.add("photos"); if(m.containsKey("video"))c.add("videos"); if(m.containsKey("animation"))c.add("gifs"); if(m.containsKey("sticker"))c.add("stickers");
  if(m.containsKey("document"))c.add("documents"); if(m.containsKey("voice"))c.add("voice"); if(m.containsKey("audio"))c.add("audio"); if(m.containsKey("video_note"))c.add("video_notes");
  if(m.containsKey("paid_media"))c.add("paid_media"); if(m.containsKey("story"))c.add("story"); if(m.containsKey("external_reply"))c.add("external_reply");
  if(m.containsKey("contact"))c.add("contact"); if(m.containsKey("location")||m.containsKey("venue"))c.add("location"); if(m.containsKey("poll"))c.add("poll"); if(m.containsKey("game")||m.containsKey("dice"))c.add("game");
  if(m.containsKey("forward_origin")||m.containsKey("forward_from")||m.containsKey("forward_from_chat"))c.add("forwards"); if(m.containsKey("reply_to_message"))c.add("reply"); if(m.containsKey("caption"))c.add("caption");
  addEntities(m.get("entities"),c);addEntities(m.get("caption_entities"),c);
  String all=String.valueOf(m.getOrDefault("text",""))+"\n"+String.valueOf(m.getOrDefault("caption",""));
  if(all.matches("(?s).*https?://\\S+.*")||all.matches("(?s).*t\\.me/\\S+.*")||all.matches("(?s).*www\\.\\S+.*"))c.add("links");
  if(containsZalgo(all))c.add("zalgo");
  for(String x:c)if(store.lock(chat,x))return x;return null;
 }
 private void addEntities(Object v,List<String> out){if(v instanceof List<?> l)for(Object e:l)if(e instanceof Map<?,?> m){String t=String.valueOf(m.get("type"));switch(t){case "mention"->out.add("mention");case "hashtag"->out.add("hashtag");case "url","text_link"->out.add("links");case "cashtag"->out.add("cashtag");default->{}}}}
 private static boolean containsZalgo(String s){int marks=0;for(int i=0;i<s.length();i++)if(Character.getType(s.charAt(i))==Character.NON_SPACING_MARK)marks++;return marks>=Math.max(8,s.length()/3);}
}
