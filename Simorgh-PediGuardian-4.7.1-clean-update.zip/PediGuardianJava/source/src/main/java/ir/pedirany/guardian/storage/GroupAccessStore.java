package ir.pedirany.guardian.storage;

import ir.pedirany.guardian.telegram.Json;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

/** Persistent 15-day group trial/entitlement registry backed by Supabase. */
public final class GroupAccessStore {
    public record Access(long chatId, String title, Instant firstSeenAt, Instant accessUntil, boolean active) {}
    private final String base;
    private final String key;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    public GroupAccessStore(){
        base=env("SUPABASE_URL","").replaceAll("/$","");
        key=env("SUPABASE_SERVICE_ROLE_KEY", env("SUPABASE_SECRET_KEY", ""));
    }
    public boolean configured(){return !base.isBlank()&&!key.isBlank();}
    public Access ensure(long chatId,String title)throws Exception{
        if(!configured()) return new Access(chatId,title,Instant.now(),Instant.now().plus(15,ChronoUnit.DAYS),true);
        HttpResponse<String> get=request("GET", "/rest/v1/group_access?telegram_chat_id=eq."+chatId+"&limit=1", null);
        List<?> rows=(List<?>)Json.parse(get.body());
        if(!rows.isEmpty()){
            Map<String,Object> m=Json.obj(rows.get(0));
            String dbTitle=String.valueOf(m.getOrDefault("title",title==null?"":title));
            boolean active=Boolean.parseBoolean(String.valueOf(m.getOrDefault("is_active","true")));
            Instant first=parseInstant(m.get("first_seen_at"), Instant.now());
            Instant until=parseInstant(m.get("access_until"), first.plus(15,ChronoUnit.DAYS));
            if(!active){ patch(chatId,"is_active",true); active=true; }
            if(title!=null&&!title.isBlank()&&!title.equals(dbTitle)) { patch2(chatId,title); dbTitle=title; }
            return new Access(chatId,dbTitle,first,until,active);
        }
        Instant now=Instant.now(), until=now.plus(15,ChronoUnit.DAYS);
        String body="{\"telegram_chat_id\":"+chatId+",\"title\":"+q(title==null?"":title)+",\"first_seen_at\":"+q(now.toString())+",\"access_until\":"+q(until.toString())+",\"is_active\":true}";
        request("POST","/rest/v1/group_access",body);
        return new Access(chatId,title==null?"":title,now,until,true);
    }
    public Access get(long chatId)throws Exception{
        if(!configured()) return null;
        HttpResponse<String> r=request("GET", "/rest/v1/group_access?telegram_chat_id=eq."+chatId+"&limit=1", null);
        List<?> rows=(List<?>)Json.parse(r.body()); if(rows.isEmpty()) return null;
        Map<String,Object> m=Json.obj(rows.get(0));
        return new Access(chatId,String.valueOf(m.getOrDefault("title","")),parseInstant(m.get("first_seen_at"),Instant.EPOCH),parseInstant(m.get("access_until"),Instant.EPOCH),Boolean.parseBoolean(String.valueOf(m.getOrDefault("is_active","true"))));
    }
    public boolean allowed(long chatId)throws Exception{
        Access a=get(chatId); return a==null || (a.active() && a.accessUntil().isAfter(Instant.now()));
    }
    public Access extend(long chatId,int days)throws Exception{
        Access a=get(chatId); if(a==null) throw new IllegalStateException("Group is not registered");
        Instant now=Instant.now(), baseAt=a.accessUntil().isAfter(now)?a.accessUntil():now, until=baseAt.plus(days,ChronoUnit.DAYS);
        String body="{\"access_until\":"+q(until.toString())+",\"is_active\":true,\"last_extended_at\":"+q(now.toString())+"}";
        request("PATCH","/rest/v1/group_access?telegram_chat_id=eq."+chatId,body);
        return new Access(chatId,a.title(),a.firstSeenAt(),until,true);
    }
    public List<Access> list(int limit)throws Exception{
        if(!configured()) return List.of();
        int n=Math.max(1,Math.min(200,limit));
        HttpResponse<String> r=request("GET","/rest/v1/group_access?select=telegram_chat_id,title,first_seen_at,access_until,is_active&order=is_active.desc,access_until.asc&limit="+n,null);
        List<?> rows=(List<?>)Json.parse(r.body()); List<Access> out=new ArrayList<>();
        for(Object o:rows){Map<String,Object> m=Json.obj(o);out.add(new Access(Long.parseLong(String.valueOf(m.get("telegram_chat_id"))),String.valueOf(m.getOrDefault("title","")),parseInstant(m.get("first_seen_at"),Instant.EPOCH),parseInstant(m.get("access_until"),Instant.EPOCH),Boolean.parseBoolean(String.valueOf(m.getOrDefault("is_active","true")))));}
        return out;
    }
    public void deactivate(long chatId)throws Exception{ if(configured()) patch(chatId,"is_active",false); }
    private void patch(long chatId,String field,Object value)throws Exception{ request("PATCH","/rest/v1/group_access?telegram_chat_id=eq."+chatId,"{\""+field+"\":"+value+"}"); }
    private void patch2(long chatId,String title)throws Exception{ request("PATCH","/rest/v1/group_access?telegram_chat_id=eq."+chatId,"{\"title\":"+q(title)+"}"); }
    private HttpResponse<String> request(String method,String path,String body)throws Exception{
        HttpRequest.Builder b=HttpRequest.newBuilder(URI.create(base+path)).timeout(Duration.ofSeconds(15)).header("apikey",key).header("Authorization","Bearer "+key).header("Content-Type","application/json");
        HttpRequest r=switch(method){case "GET"->b.GET().build();case "POST"->b.POST(HttpRequest.BodyPublishers.ofString(body==null?"":body, StandardCharsets.UTF_8)).build();case "PATCH"->b.method("PATCH",HttpRequest.BodyPublishers.ofString(body==null?"":body, StandardCharsets.UTF_8)).build();default->throw new IllegalArgumentException(method);};
        HttpResponse<String> out=http.send(r,HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)); if(out.statusCode()<200||out.statusCode()>=300)throw new IllegalStateException("Supabase group access HTTP "+out.statusCode()+": "+out.body()); return out;
    }
    private static Instant parseInstant(Object v,Instant d){try{return v==null?d:Instant.parse(String.valueOf(v));}catch(Exception e){return d;}}
    private static String env(String k,String d){String v=System.getenv(k);return v==null||v.isBlank()?d:v.trim();}
    private static String q(String s){String x=s==null?"":s.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ").replace("\r"," ");return "\""+x+"\"";}
}
