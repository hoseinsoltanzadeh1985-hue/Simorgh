package ir.pedirany.guardian.commands;

import ir.pedirany.guardian.security.SecurityService;
import ir.pedirany.guardian.storage.StateStore;
import ir.pedirany.guardian.telegram.Json;
import ir.pedirany.guardian.telegram.TelegramClient;
import java.util.Map;

/** Immutable per-update context shared by handlers. */
public record CommandContext(TelegramClient api, StateStore store, SecurityService security,
                             long chatId, long userId, long messageId, String text,
                             Map<String,Object> message) {
    public Long replyMessageId() {
        Object r = message == null ? null : message.get("reply_to_message");
        if (!(r instanceof Map)) return null;
        Object id = Json.obj(r).get("message_id");
        return id instanceof Number n ? n.longValue() : null;
    }
    public Long replyUserId() {
        Object r = message == null ? null : message.get("reply_to_message");
        if (!(r instanceof Map)) return null;
        Object f = Json.obj(r).get("from");
        if (!(f instanceof Map)) return null;
        Object id = Json.obj(f).get("id");
        return id instanceof Number n ? n.longValue() : null;
    }
    public SecurityService.Role role() throws Exception { return security.role(chatId, userId); }
}
