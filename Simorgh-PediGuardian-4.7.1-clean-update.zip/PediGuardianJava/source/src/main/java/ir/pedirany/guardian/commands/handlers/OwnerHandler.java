package ir.pedirany.guardian.commands.handlers;

import ir.pedirany.guardian.commands.CommandContext;
import ir.pedirany.guardian.commands.CommandHandler;
import ir.pedirany.guardian.storage.GroupAccessStore;
import java.time.Duration;
import java.time.Instant;

public final class OwnerHandler {
    private OwnerHandler(){}
    public static CommandHandler groups(GroupAccessStore access){return c->{
        if(c.userId()!=c.security().botOwnerId()){c.api().sendMessage(c.chatId(),"⛔ این دستور فقط برای مالک ربات است.");return;}
        if(!access.configured()){c.api().sendMessage(c.chatId(),"⚠️ Supabase برای دفتر گروه‌ها تنظیم نشده است.");return;}
        var rows=access.list(100); if(rows.isEmpty()){c.api().sendMessage(c.chatId(),"📭 هنوز گروهی ثبت نشده است.");return;}
        StringBuilder b=new StringBuilder("👑 <b>گروه‌های متصل به PediGuardian</b>\n\n");
        for(var a:rows){
            long days=Math.max(0,Duration.between(Instant.now(),a.accessUntil()).toDays());
            String state=a.active()&&a.accessUntil().isAfter(Instant.now())?"🟢 فعال":"🔴 منقضی";
            b.append(state).append(" ").append(esc(a.title().isBlank()?"بدون عنوان":a.title())).append("\n");
            b.append("<code>").append(a.chatId()).append("</code> · ").append(days).append(" روز مانده\n\n");
        }
        c.api().sendMessage(c.chatId(),b.toString(),null,true);
    };}
    public static CommandHandler extend(GroupAccessStore access){return c->{
        if(c.userId()!=c.security().botOwnerId()){c.api().sendMessage(c.chatId(),"⛔ فقط مالک ربات می‌تواند تمدید کند.");return;}
        String[] p=c.text().trim().split("\\s+"); if(p.length<3){c.api().sendMessage(c.chatId(),"استفاده: /extend <chat_id> <days>\nمثال: /extend -1001234567890 30");return;}
        long chat; int days; try{chat=Long.parseLong(p[1]);days=Integer.parseInt(p[2]);}catch(Exception e){c.api().sendMessage(c.chatId(),"⚠️ chat_id و days باید عدد باشند.");return;}
        if(days<1||days>3650){c.api().sendMessage(c.chatId(),"⚠️ مدت تمدید باید بین ۱ تا ۳۶۵۰ روز باشد.");return;}
        try{var a=access.extend(chat,days);c.api().sendMessage(c.chatId(),"✅ تمدید شد\n<b>"+esc(a.title())+"</b>\n<code>"+chat+"</code>\nتا: <b>"+a.accessUntil()+"</b>",null,true);c.store().audit(c.chatId(),c.userId(),"GROUP_EXTEND",chat+" +"+days+"d");}
        catch(Exception e){c.api().sendMessage(c.chatId(),"⚠️ گروه ثبت نشده یا Supabase در دسترس نیست.");}
    };}
    public static CommandHandler trial(GroupAccessStore access){return c->{
        try{var a=access.get(c.chatId());if(a==null){c.api().sendMessage(c.chatId(),"ℹ️ این گروه هنوز ثبت نشده است.");return;}var now=Instant.now();boolean ok=a.active()&&a.accessUntil().isAfter(now);long days=Math.max(0,Duration.between(now,a.accessUntil()).toDays());c.api().sendMessage(c.chatId(),(ok?"🟢":"🔴")+" <b>وضعیت سرویس گروه</b>\n"+(ok?"رایگان/فعال":"دوره تمام شده")+"\nتا: <b>"+a.accessUntil()+"</b>\nروز باقی‌مانده: <b>"+days+"</b>",null,true);}catch(Exception e){c.api().sendMessage(c.chatId(),"⚠️ وضعیت سرویس فعلاً قابل دریافت نیست.");}
    };}
    private static String esc(String s){return String.valueOf(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
}
