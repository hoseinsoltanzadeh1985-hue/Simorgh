package ir.pedirany.guardian.voice;

import java.net.URI;
import java.net.http.*;
import java.time.Duration;

/** Queues a non-monetary current-Voice-Chat roster selection. */
public final class VoiceOrderQueue {
    private final String base;
    private final String key;
    private final HttpClient http=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    public VoiceOrderQueue(){base=env("SUPABASE_URL","").replaceAll("/$","");key=env("SUPABASE_SECRET_KEY",env("SUPABASE_SERVICE_ROLE_KEY",""));}
    public boolean configured(){return !base.isBlank()&&!key.isBlank();}
    public void request(long chat,long actor,int count)throws Exception{
        if(!configured()) throw new IllegalStateException("Supabase voice queue is not configured");
        int n=Math.max(1,Math.min(20,count));
        long groupId=resolveGroupId(chat);
        String payload="{\"group_id\":"+groupId+",\"requested_by\":"+actor+",\"count\":"+n+",\"status\":\"PENDING\"}";
        HttpRequest r=HttpRequest.newBuilder(URI.create(base+"/rest/v1/voice_order_requests"))
                .timeout(Duration.ofSeconds(15)).header("apikey",key).header("Authorization","Bearer "+key)
                .header("Content-Type","application/json").header("Prefer","return=minimal")
                .POST(HttpRequest.BodyPublishers.ofString(payload)).build();
        HttpResponse<String> out=http.send(r,HttpResponse.BodyHandlers.ofString());
        if(out.statusCode()<200||out.statusCode()>=300)throw new IllegalStateException("voice queue HTTP "+out.statusCode()+": "+out.body());
    }
    private long resolveGroupId(long chat)throws Exception{
        String url=base+"/rest/v1/groups?telegram_chat_id=eq."+chat+"&select=id&limit=1";
        HttpRequest r=HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15)).header("apikey",key).header("Authorization","Bearer "+key).GET().build();
        HttpResponse<String> out=http.send(r,HttpResponse.BodyHandlers.ofString());
        if(out.statusCode()<200||out.statusCode()>=300)throw new IllegalStateException("group lookup HTTP "+out.statusCode());
        String body=out.body();int i=body.indexOf("\"id\"");if(i<0)throw new IllegalStateException("group not registered");int colon=body.indexOf(':',i);int end=colon+1;while(end<body.length()&&Character.isWhitespace(body.charAt(end)))end++;int j=end;while(j<body.length()&&Character.isDigit(body.charAt(j)))j++;if(j==end)throw new IllegalStateException("invalid group id");return Long.parseLong(body.substring(end,j));
    }
    private static String env(String k,String d){String v=System.getenv(k);return v==null||v.isBlank()?d:v.trim();}
}
