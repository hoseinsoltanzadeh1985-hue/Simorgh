package ir.pedirany.guardian.i18n;
public final class I18n{
 public String help(boolean fa){
  if(!fa)return "📚 Help\n/start /panel /status /id /profile /rules /language /version\n/games /airraider /backgammon /emoji /ai /aistatus /voiceorder /wheel\nModeration: /warn /warnings /clearwarnings /mute /unmute /ban /unban /kick /del /pin /unpin\nSecurity: /lock /unlock /locks /antiraid /admins /perms /logs /settings /setrules /welcome /setwelcome /filter /filters /badword /badwords\nOwner: /groups /trial /extend";
  return "📚 <b>راهنما | Help</b>\n\n<b>عمومی</b>\n/start • /panel • /status • /id • /profile • /rules • /language • /version\n\n<b>🎮 بازی</b>\n/game • /airraider • /backgammon\n\n<b>🤖 هوش و ابزار</b>\n/ai • /aistatus • /emoji\n\n<b>🎙️ Voice</b>\n/voiceorder • /wheel (1..20)\n\n<b>🛡️ مدیریت و امنیت</b>\n/warn • /warnings • /clearwarnings • /mute • /unmute • /ban • /unban • /kick • /del • /pin • /unpin\n/lock • /unlock • /locks • /antiraid • /admins • /perms • /logs\n/settings • /setrules • /welcome • /setwelcome • /filter • /filters • /badword • /badwords • /settag\n\n<b>👑 مالک ربات</b>\n/groups • /trial • /extend";
 }
}
