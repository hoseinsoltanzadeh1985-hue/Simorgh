package ir.pedirany.guardian.security;
import java.util.*;import java.util.concurrent.*;
public final class FloodDetector implements AutoCloseable{
 private record Key(long c,long u){} private record Bucket(Deque<Long>q,long touched){} private final long windowMs;private final int max;private final ConcurrentHashMap<Key,Bucket>map=new ConcurrentHashMap<>();private final ScheduledExecutorService cleaner=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"flood-cleaner");t.setDaemon(true);return t;});
 public FloodDetector(int max,long windowMs){this.max=Math.max(1,max);this.windowMs=Math.max(500,windowMs);cleaner.scheduleAtFixedRate(this::cleanup,1,1,TimeUnit.MINUTES);}
 public boolean hit(long c,long u){long now=System.currentTimeMillis();Key k=new Key(c,u);Bucket b=map.computeIfAbsent(k,x->new Bucket(new ArrayDeque<>(),now));synchronized(b.q){while(!b.q.isEmpty()&&now-b.q.peekFirst()>windowMs)b.q.removeFirst();b.q.addLast(now);return b.q.size()>max;}}
 private void cleanup(){long cutoff=System.currentTimeMillis()-Math.max(windowMs*4,300_000L);map.entrySet().removeIf(e->e.getValue().touched()<cutoff);} public void clear(long c,long u){map.remove(new Key(c,u));} public void close(){cleaner.shutdownNow();}
}
