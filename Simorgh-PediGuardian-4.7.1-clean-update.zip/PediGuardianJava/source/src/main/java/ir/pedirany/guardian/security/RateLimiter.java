package ir.pedirany.guardian.security;
import java.time.Instant;import java.util.*;import java.util.concurrent.*;
public final class RateLimiter{
 private record Bucket(long window,int count,long touched){} private final int max;private final ConcurrentHashMap<String,Bucket> buckets=new ConcurrentHashMap<>();private final ScheduledExecutorService cleaner=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"rate-cleaner");t.setDaemon(true);return t;});
 public RateLimiter(int max){this.max=Math.max(1,max);cleaner.scheduleAtFixedRate(this::cleanup,2,2,TimeUnit.MINUTES);}
 public boolean allow(long chat,long user){long w=Instant.now().getEpochSecond()/60;final boolean[] ok={false};buckets.compute(chat+":"+user,(k,b)->{if(b==null||b.window()!=w){ok[0]=true;return new Bucket(w,1,System.currentTimeMillis());}if(b.count()<max){ok[0]=true;return new Bucket(w,b.count()+1,System.currentTimeMillis());}return new Bucket(b.window(),b.count(),System.currentTimeMillis());});if(buckets.size()>Math.max(4096,max*256))cleanup();return ok[0];}
 public boolean allow(long user){return allow(0,user);} private void cleanup(){long cutoff=System.currentTimeMillis()-10*60_000L;buckets.entrySet().removeIf(e->e.getValue().touched()<cutoff);} public void close(){cleaner.shutdownNow();}
}
