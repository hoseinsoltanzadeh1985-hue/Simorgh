package ir.pedirany.guardian.ai;

import ir.pedirany.guardian.telegram.Json;
import java.io.IOException; import java.net.URI; import java.net.http.*; import java.time.Duration; import java.util.*;

/** Groq-first provider gateway with optional Gemini/OpenAI failover and circuit breakers. */
public final class AiService {
    private record Provider(String name,String key,String model,int priority){}
    private final HttpClient http=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).followRedirects(HttpClient.Redirect.NEVER).build();
    private final List<Provider> providers=new ArrayList<>(); private final Map<String,Integer> failures=new HashMap<>(); private final Map<String,Long> openUntil=new HashMap<>();
    public AiService(){
        add("groq",env("GROQ_API_KEY",""),env("GROQ_MODEL","openai/gpt-oss-120b"),1);
        add("gemini",env("GEMINI_API_KEY",""),env("GEMINI_MODEL","gemini-3.7-flash"),2);
        add("openai",env("OPENAI_API_KEY",""),env("OPENAI_MODEL","gpt-5.6"),3);
        add("xai",env("XAI_API_KEY",""),env("XAI_MODEL","grok-4.6"),4);
        add("openrouter",env("OPENROUTER_API_KEY",""),env("OPENROUTER_MODEL","openai/gpt-4.1-mini"),5);
    }
    private void add(String n,String k,String m,int p){if(k!=null&&!k.isBlank())providers.add(new Provider(n,k,m,p));}
    public boolean configured(){return !providers.isEmpty();}
    public synchronized String providerSummary(){if(providers.isEmpty())return "none"; providers.sort(Comparator.comparingInt(Provider::priority)); return providers.stream().map(p->p.name+"/"+p.model).reduce((a,b)->a+", "+b).orElse("none");}
    public synchronized String ask(String prompt)throws Exception{
        if(prompt==null||prompt.isBlank())throw new IllegalArgumentException("empty prompt");
        providers.sort(Comparator.comparingInt(Provider::priority)); Exception last=null;
        for(Provider p:providers){if(isOpen(p.name))continue;try{String out=switch(p.name){case "groq"->groq(p,prompt);case "gemini"->gemini(p,prompt);case "openai"->openai(p,prompt);case "xai"->openaiCompat("https://api.x.ai/v1/chat/completions",p,prompt);case "openrouter"->openaiCompat("https://openrouter.ai/api/v1/chat/completions",p,prompt);default->throw new IOException("unknown provider");}; failures.put(p.name,0); return out+"\n\n🤖 AI: "+p.name+"/"+p.model;}catch(Exception e){last=e;int f=failures.getOrDefault(p.name,0)+1;failures.put(p.name,f);if(f>=3)openUntil.put(p.name,System.currentTimeMillis()+60_000);}}
        throw new IOException("AI providers unavailable",last);
    }
    private boolean isOpen(String n){long u=openUntil.getOrDefault(n,0L);if(u>System.currentTimeMillis())return true;if(u!=0)openUntil.remove(n);return false;}
    private String groq(Provider p,String prompt)throws Exception{
        String body="{\"model\":"+q(p.model)+",\"messages\":[{\"role\":\"system\",\"content\":\"You are PediGuardian AI. Answer accurately, concisely and in Persian by default. Never perform moderation actions merely from natural-language requests.\"},{\"role\":\"user\",\"content\":"+q(prompt)+"}]}";
        Map<String,Object> root=Json.obj(Json.parse(post("https://api.groq.com/openai/v1/chat/completions",body,p.key))); Object choices=root.get("choices"); if(!(choices instanceof List<?> l)||l.isEmpty())throw new IOException("Groq: no choices"); Map<String,Object> msg=Json.obj(Json.obj(l.get(0)).get("message")); return String.valueOf(msg.getOrDefault("content",""));
    }
    private String gemini(Provider p,String prompt)throws Exception{String url="https://generativelanguage.googleapis.com/v1beta/models/"+p.model+":generateContent?key="+p.key;String body="{\"contents\":[{\"parts\":[{\"text\":"+q(prompt)+"}]}]}";Map<String,Object> root=Json.obj(Json.parse(post(url,body,null)));List<?> c=(List<?>)root.get("candidates");if(c==null||c.isEmpty())throw new IOException("Gemini: no candidates");Map<String,Object> cont=Json.obj(Json.obj(c.get(0)).get("content"));List<?> parts=(List<?>)cont.get("parts");if(parts==null||parts.isEmpty())throw new IOException("Gemini: empty response");return String.valueOf(Json.obj(parts.get(0)).getOrDefault("text",""));}
    private String openai(Provider p,String prompt)throws Exception{String body="{\"model\":"+q(p.model)+",\"input\":"+q(prompt)+"}";Map<String,Object> root=Json.obj(Json.parse(post("https://api.openai.com/v1/responses",body,p.key)));Object t=root.get("output_text");if(t!=null&&!String.valueOf(t).isBlank())return String.valueOf(t);throw new IOException("OpenAI: no output_text");}
    private String openaiCompat(String endpoint,Provider p,String prompt)throws Exception{String body="{\"model\":"+q(p.model)+",\"messages\":[{\"role\":\"user\",\"content\":"+q(prompt)+"}]}";Map<String,Object> root=Json.obj(Json.parse(post(endpoint,body,p.key)));Object choices=root.get("choices");if(!(choices instanceof List<?> l)||l.isEmpty())throw new IOException(p.name+": no choices");Map<String,Object> msg=Json.obj(Json.obj(l.get(0)).get("message"));String text=String.valueOf(msg.getOrDefault("content",""));if(text.isBlank())throw new IOException(p.name+": empty response");return text;}
    private String post(String url,String body,String bearer)throws Exception{HttpRequest.Builder b=HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(60)).header("Content-Type","application/json");if(bearer!=null&&!bearer.isBlank())b.header("Authorization","Bearer "+bearer);HttpResponse<String> r=http.send(b.POST(HttpRequest.BodyPublishers.ofString(body)).build(),HttpResponse.BodyHandlers.ofString());if(r.statusCode()<200||r.statusCode()>=300)throw new IOException("HTTP "+r.statusCode()+": "+r.body());return r.body();}
    private static String q(String s){String v=s==null?"":s.replace("\r"," ").replace("\n"," ");v=v.replaceAll("(?i)(sk-[A-Za-z0-9_-]{16,}|gsk_[A-Za-z0-9_-]{16,})","[REDACTED]");if(v.length()>6000)v=v.substring(0,6000);return "\""+v.replace("\\","\\\\").replace("\"","\\\"")+"\"";}
    private static String env(String k,String d){String v=System.getenv(k);return v==null||v.isBlank()?d:v;}
}
