package ir.pedirany.guardian.storage;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.regex.Pattern;

/**
 * Optional server-side Supabase sink. Service keys are read only from environment
 * variables and are never exposed to Telegram clients or included in output logs.
 */
public final class SupabaseAuditSink {
    private static final Pattern SAFE_NAME = Pattern.compile("[A-Za-z_][A-Za-z0-9_]{0,62}");
    private final String baseUrl;
    private final String key;
    private final String auditTable;
    private final boolean required;
    private final HttpClient client;
    private final int timeoutSeconds;

    public SupabaseAuditSink() {
        this.baseUrl = trimSlash(env("SUPABASE_URL", ""));
        this.key = env("SUPABASE_SECRET_KEY", env("SUPABASE_SERVICE_ROLE_KEY", ""));
        this.auditTable = safeName(env("SUPABASE_AUDIT_TABLE", "audit_logs"), "audit_logs");
        this.required = boolEnv("SUPABASE_REQUIRED", false);
        this.timeoutSeconds = Math.max(2, Math.min(30, intEnv("SUPABASE_HTTP_TIMEOUT_SECONDS", 8)));
        this.client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(timeoutSeconds))
                .followRedirects(HttpClient.Redirect.NEVER)
                .build();
    }

    public boolean enabled() { return !baseUrl.isBlank() && !key.isBlank(); }
    public boolean required() { return required; }

    /** Atomically claims an update through the database RPC. */
    public boolean claimUpdate(long updateId) throws Exception {
        if (!enabled()) return true;
        HttpResponse<String> r = send("/rest/v1/rpc/claim_processed_update",
                "{\"p_update_id\":" + updateId + "}", "POST", false);
        if (r.statusCode() < 200 || r.statusCode() >= 300) {
            throw new IOException("Supabase claim HTTP " + r.statusCode());
        }
        String body = r.body() == null ? "" : r.body().trim().toLowerCase();
        if ("true".equals(body) || "[true]".equals(body)) return true;
        if ("false".equals(body) || "[false]".equals(body)) return false;
        throw new IOException("Supabase claim returned invalid response");
    }

    public void write(long chatId, long actorId, Long targetId, String requestId,
                      String action, String result) throws Exception {
        if (!enabled()) return;
        StringBuilder b = new StringBuilder("{\"group_id\":").append(chatId)
                .append(",\"actor_user_id\":").append(actorId)
                .append(",\"action\":").append(q(action))
                .append(",\"metadata\":{\"result\":").append(q(result));
        if (targetId != null) b.append(",\"target_user_id\":").append(targetId);
        if (requestId != null && !requestId.isBlank()) b.append(",\"request_id\":").append(q(requestId));
        b.append("}}");
        HttpResponse<String> r = send("/rest/v1/" + auditTable, b.toString(), "POST", true);
        if (r.statusCode() == 409) return;
        if (r.statusCode() < 200 || r.statusCode() >= 300) {
            throw new IOException("Supabase audit HTTP " + r.statusCode());
        }
    }

    private HttpResponse<String> send(String path, String body, String method, boolean ignoreDuplicates) throws Exception {
        if (!enabled()) throw new IllegalStateException("Supabase sink is disabled");
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(baseUrl + path))
                .timeout(Duration.ofSeconds(timeoutSeconds))
                .header("apikey", key)
                .header("Authorization", "Bearer " + key)
                .header("Content-Type", "application/json");
        if (ignoreDuplicates) b.header("Prefer", "resolution=ignore-duplicates,return=minimal");
        HttpRequest r = switch (method) {
            case "GET" -> b.GET().build();
            case "POST" -> b.POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8)).build();
            default -> throw new IllegalArgumentException("Unsupported method");
        };
        return client.send(r, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
    }

    private static String env(String k, String d) { String v = System.getenv(k); return v == null || v.isBlank() ? d : v; }
    private static boolean boolEnv(String k, boolean d) { String v = env(k, String.valueOf(d)); return "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v); }
    private static int intEnv(String k, int d) { try { return Integer.parseInt(env(k, String.valueOf(d))); } catch (Exception e) { return d; } }
    private static String trimSlash(String v) { return v == null ? "" : v.replaceAll("/+$", ""); }
    private static String safeName(String v, String fallback) { return v != null && SAFE_NAME.matcher(v).matches() ? v : fallback; }
    private static String q(String s) { return "\"" + String.valueOf(s).replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ") + "\""; }
}
