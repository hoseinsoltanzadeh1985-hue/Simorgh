package ir.pedirany.guardian;

import ir.pedirany.guardian.core.App;

public final class Main {
    private Main() {}
    public static void main(String[] args) throws Exception {
        App app = App.fromEnvironment();
        app.start();
    }
}
