package ir.pedirany.guardian.commands;

@FunctionalInterface
public interface CommandHandler {
    void handle(CommandContext ctx) throws Exception;
}
