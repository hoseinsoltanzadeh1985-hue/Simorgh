package ir.pedirany.guardian.games;

import ir.pedirany.guardian.telegram.TelegramClient;
import ir.pedirany.guardian.security.SecurityService;

/** Game launcher. Uses a static HTTPS host for Mini Apps; Supabase Edge Functions remain API-only. */
public final class GameCenter {
    private static final String DEFAULT_BASE = "https://cdn.jsdelivr.net/gh/hoseinsoltanzadeh1985-hue/PediGuardian-4.4@6f3ee56a18e9ff0599f0ae5ceb70bd7e5ef7ab04/games";
    private final TelegramClient api;
    private final String airUrl;
    private final String backgammonUrl;
    private final String launcherUrl;

    public GameCenter(TelegramClient a){
        api=a;
        String base=trimSlash(env("GAMES_BASE_URL",DEFAULT_BASE));
        airUrl=preferredUrl(env("AIR_RAIDER_URL",""),base+"/air-raider/index.html");
        backgammonUrl=preferredUrl(env("BACKGAMMON_URL",""),base+"/backgammon/index.html");
        launcherUrl=base+"/index.html";
    }

    public void show(long chat,long user,SecurityService sec)throws Exception{
        if(!sec.allowed(chat,user,SecurityService.Permission.GAME)){api.sendMessage(chat,"⛔ دسترسی بازی ندارید.");return;}
        String body="🎮 <b>Simorgh Game Center 4.7.1</b>\n\n✈️ Air Raider — آرکید\n🎲 Backgammon — تخته نرد با AI\n\nهر دو بازی از HTTPS Static Mini App اجرا می‌شوند.";
        api.sendRichOrText(chat,body,buttons(),true,user,false,"");
    }
    public void air(long chat,long user,SecurityService sec)throws Exception{ openOne(chat,user,sec,"✈️ Air Raider",airUrl); }
    public void backgammon(long chat,long user,SecurityService sec)throws Exception{ openOne(chat,user,sec,"🎲 Backgammon",backgammonUrl); }
    public String urls(){return "Air="+airUrl+" | Backgammon="+backgammonUrl+" | Launcher="+launcherUrl;}
    private void openOne(long chat,long user,SecurityService sec,String title,String url)throws Exception{
        if(!sec.allowed(chat,user,SecurityService.Permission.GAME)){api.sendMessage(chat,"⛔ دسترسی بازی ندارید.");return;}
        api.sendRichOrText(chat,"🎮 <b>"+title+" | Simorgh</b>","{\"inline_keyboard\":[[{\"text\":\"▶️ اجرا\",\"web_app\":{\"url\":"+TelegramClient.q(url)+"}}]]}",true,user,false,"");
    }
    private String buttons(){
        return "{\"inline_keyboard\":[["+
            "{\"text\":\"✈️ Air Raider\",\"web_app\":{\"url\":"+TelegramClient.q(airUrl)+"}},"+
            "{\"text\":\"🎲 Backgammon\",\"web_app\":{\"url\":"+TelegramClient.q(backgammonUrl)+"}}"+
            "],[{\"text\":\"🎮 Game Center\",\"web_app\":{\"url\":"+TelegramClient.q(launcherUrl)+"}}]]}";
    }
    private static String env(String k,String d){String v=System.getenv(k);return v==null||v.isBlank()?d:v.trim();}
    private static String trimSlash(String s){return s.replaceAll("/+$","");}
    private static String preferredUrl(String configured,String fallback){
        if(configured==null||configured.isBlank()) return fallback;
        String u=configured.trim();
        if(u.contains("/functions/v1/")||u.contains("supabase.co/functions/")) return fallback;
        return u;
    }
}
