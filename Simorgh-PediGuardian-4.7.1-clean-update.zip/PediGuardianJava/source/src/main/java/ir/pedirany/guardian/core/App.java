package ir.pedirany.guardian.core;

import ir.pedirany.guardian.commands.CommandRouter;
import ir.pedirany.guardian.i18n.I18n;
import ir.pedirany.guardian.security.RateLimiter;
import ir.pedirany.guardian.security.SecurityService;
import ir.pedirany.guardian.storage.StateStore;
import ir.pedirany.guardian.storage.SupabaseAuditSink;
import ir.pedirany.guardian.telegram.TelegramClient;
import ir.pedirany.guardian.telegram.UpdatePoller;

public final class App {
    private final TelegramClient telegram;
    private final StateStore store;
    private final CommandRouter router;
    private final UpdatePoller poller;
    private final Config config;
    private final SupabaseAuditSink cloud;

    private App(Config c) throws Exception {
        config = c;
        telegram = new TelegramClient(c.token());
        store = new StateStore(c.dataFile());
        cloud = new SupabaseAuditSink();
        SecurityService sec = new SecurityService(telegram, store, c.botOwnerId());
        RateLimiter limiter = new RateLimiter(c.rateLimitPerMinute());
        router = new CommandRouter(telegram, store, sec, limiter, new I18n(), c.gameUrl());
        poller = new UpdatePoller(telegram, router, c.pollTimeout(), cloud);
    }

    public static App fromEnvironment() throws Exception { return new App(Config.fromEnv()); }

    public void start() throws Exception {
        store.load();
        var me = telegram.getMe();
        System.out.println("PediGuardian 4.7 Guardian controller started mode=" + config.deploymentMode());
        if (cloud.enabled()) {
            System.out.println("Supabase sink: enabled (server-side only)");
            if (config.strictStartup()) {
                try { cloud.claimUpdate(-900000000000001L); }
                catch (Exception e) { throw new IllegalStateException("Supabase health/idempotency check failed", e); }
            }
        }
        try { telegram.setCommands(); }
        catch (Exception e) { System.err.println("Command menu setup failed: " + e.getMessage()); if (config.strictStartup()) throw e; }
        if (config.deploymentMode().equals("cloud")) {
            System.out.println("Cloud mode: externally managed webhook remains active; polling disabled.");
            return;
        }
        telegram.deleteWebhook();
        poller.runForever();
    }
}
