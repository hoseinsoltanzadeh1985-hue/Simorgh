# Simorgh / PediGuardian 4.7.1

این بسته یک اصلاح واقعی برای نسخه 4.7.0 است:

- Game Center اکنون هر دو بازی Air Raider و Backgammon را نشان می‌دهد.
- Mini Appها دیگر از Supabase Edge Function برای HTML استفاده نمی‌کنند؛ لینک پیش‌فرض روی GitHub/jsDelivr است.
- `/airraider` و `/backgammon` اضافه شده‌اند.
- `/wheel` به‌عنوان alias برای `/voiceorder` اضافه شده است.
- `/report`, `/reports`, `/note`, `/notes`, `/config` فعال شده‌اند.
- Help و Command Menu تکمیل شده‌اند و `/purge` که handler واقعی نداشت از منوی ادمین حذف شده است.
- Voice queue قبل از ایجاد درخواست، `groups.id` داخلی را از `telegram_chat_id` پیدا می‌کند.
- Polling در Local Mode گزارش واضح دریافت Update می‌دهد.
- متن‌های قدیمی 4.4/Cloud از Start و Version حذف شده‌اند.
- AI Gateway با providerهای environment-based باقی مانده است.

## AI مدل‌های پیش‌فرض

Groq: `openai/gpt-oss-120b`
Gemini: `gemini-3.7-flash`
OpenAI: `gpt-5.6`

کلیدها هرگز داخل Git یا این بسته ذخیره نشده‌اند.

## اجرای Termux

Updater را از Downloads اجرا کنید. `.env` دست‌نخورده می‌ماند.

در Local Mode:

```bash
cd ~/PediGuardian/PediGuardianJava
set -a && . ./.env && set +a
DEPLOYMENT_MODE=local java -jar pedi-guardian-java-4.7.1.jar
```

در Production Cloud، Java نباید Polling را همزمان با Webhook انجام دهد.

## Static Mini Apps

نسخه GitHub در commit `6f3ee56a18e9ff0599f0ae5ceb70bd7e5ef7ab04` بازی‌ها را در مسیر `games/` دارد. GameCenter از jsDelivr با همان commit استفاده می‌کند تا محتوای ثابت و قابل cache باشد.

این انتخاب با محدودیت فعلی Supabase Edge Functions سازگار است: Edge Functions برای API/runtime هستند و HTML باید از hosting مناسب سرو شود.
