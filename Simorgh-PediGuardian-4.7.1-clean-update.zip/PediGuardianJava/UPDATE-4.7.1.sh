#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="$HOME/PediGuardian/PediGuardianJava"
JAR="pedi-guardian-java-4.7.1.jar"
mkdir -p "$TARGET" "$TARGET/backups"
if [[ -f "$TARGET/.env" ]]; then cp -p "$TARGET/.env" "$TARGET/backups/.env.4.7.1.$(date +%Y%m%d-%H%M%S)"; fi
for old in pedi-guardian-java-4.4.0-patched.jar pedi-guardian-java-4.5.2.jar pedi-guardian-java-4.6.1-command-engines.jar pedi-guardian-java-4.7.0.jar; do
  [[ -f "$TARGET/$old" ]] && cp -p "$TARGET/$old" "$TARGET/backups/$old.$(date +%Y%m%d-%H%M%S)" || true
done
pkill -f 'pedi-guardian-java-4\.[4567]\.' 2>/dev/null || true
sleep 2
cp -p "$SRC_DIR/$JAR" "$TARGET/$JAR"
mkdir -p "$TARGET/branding" "$TARGET/games"
cp -p "$SRC_DIR/branding/"* "$TARGET/branding/"
cp -p "$SRC_DIR/games/"* "$TARGET/games/"
printf '%s\n' '4.7.1 installed.' 'env preserved.' 'games and branding installed.'
printf '%s\n' 'Run manually:'
printf '%s\n' 'cd ~/PediGuardian/PediGuardianJava && set -a && . ./.env && set +a && DEPLOYMENT_MODE=local java -jar pedi-guardian-java-4.7.1.jar'
