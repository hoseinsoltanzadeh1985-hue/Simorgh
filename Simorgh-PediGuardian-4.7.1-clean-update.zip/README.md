# 🦅 Simorgh | PediGuardian 4.7.1 — Clean Update

این بسته برای جایگزینی نسخه 4.7.0 روی Termux ساخته شده است.

## چه چیزهایی اصلاح شده؟

**Telegram / Command Engine**
- `/start`, `/help`, `/panel`, `/status`, `/version`
- `/game`, `/airraider`, `/backgammon`
- `/voiceorder`, `/wheel`
- `/report`, `/reports`, `/note`, `/notes`, `/config`
- مدیریت، قفل‌ها، Anti-Raid، RBAC و Native Telegram permissions

**Games**
- ✈️ Air Raider
- 🎲 Backgammon + AI
- Game Center هر دو بازی را همزمان نشان می‌دهد.
- بازی‌ها بدون شرط‌بندی و پرداخت طراحی شده‌اند.

**Voice**
- گردونه = انتخاب تصادفی از اعضای حاضر در Voice Chat در لحظه اجرا
- بدون وزن‌دهی، سابقه حضور یا امتیازدهی
- درخواست‌ها با `groups.id` داخلی Supabase ثبت می‌شوند.

**AI**
- Groq → Gemini → OpenAI → providerهای اختیاری
- کلیدها فقط از Environment خوانده می‌شوند.

**Branding**
- عکس پروفایل 640×640
- تصویر Start/Welcome 1280×720
- نام و About/Description نسخه 4.7.1 در Java

## نکته مهم بازی‌ها

Supabase Edge Functions برای API/runtime هستند و HTML آنها مسیر مناسبی برای Mini App نیست. نسخه 4.7.1 بازی‌ها را از GitHub/jsDelivr به‌صورت static HTTPS سرو می‌کند.

## نصب

فایل ZIP را در `~/storage/downloads` قرار دهید، سپس:

```bash
cd ~/storage/downloads && rm -rf ~/Simorgh-4.7.1-update && mkdir -p ~/Simorgh-4.7.1-update && unzip -q Simorgh-PediGuardian-4.7.1-clean-update.zip -d ~/Simorgh-4.7.1-update && cd ~/Simorgh-4.7.1-update/PediGuardianJava && ./UPDATE-4.7.1.sh
```

پس از نصب، Java را دستی در Local Mode اجرا کنید تا رفتار را مرحله‌به‌مرحله تست کنیم.
